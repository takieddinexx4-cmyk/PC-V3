'use strict';
const $ = (id) => document.getElementById(id);
const call = (...a) => (window.api ? window.api.call(...a) : Promise.resolve({ ok: false }));
const esc = (s) =>
  String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const SEG = {
  maxSize: ['الدقة', [['الأصلية', 0], ['2K', 2560], ['1080p', 1920], ['720p', 1280]]],
  fps: ['السلاسة (FPS)', [['30', 30], ['60', 60], ['90', 90], ['120', 120]]],
  bitrate: ['معدل البت (Mbps)', [['8', 8], ['16', 16], ['24', 24], ['40', 40], ['64', 64]]],
  codec: ['الترميز', [['H.264 (الأسرع)', 'h264'], ['H.265 (أنقى)', 'h265']]],
  mode: ['نمط الاستجابة', [['⚡ سرعة (ألعاب)', 'fast'], ['💎 جودة نقيّة', 'quality']]],
  renderDriver: ['محرك الرسوميات', [['Direct3D', 'direct3d'], ['OpenGL', 'opengl'], ['تلقائي', 'auto']]]
};

const QUICK_SEG_KEYS = ['maxSize', 'fps', 'bitrate'];

const TOG = [
  ['audio', '🔊 بث صوت الهاتف (أندرويد 11+)'],
  ['autoReconnect', '🔄 إعادة الاتصال التلقائي عند انقطاع البث'],
  ['awake', '☀️ إبقاء الهاتف مستيقظاً أثناء البث'],
  ['off', '🌙 إطفاء شاشة الهاتف لتوفير البطارية'],
  ['touch', '👆 إظهار نقاط اللمس'],
  ['top', '📌 تثبيت نافذة البث فوق النوافذ'],
  ['borderless', '🖼 نافذة بدون حواف (سينمائي)'],
  ['view', '👁 وضع العرض فقط (بدون تحكم)']
];

const PRESETS = {
  game: { maxSize: 1280, fps: 90, bitrate: 16, codec: 'h264', mode: 'fast' },
  bal: { maxSize: 1920, fps: 60, bitrate: 24, codec: 'h264', mode: 'fast' },
  max: { maxSize: 0, fps: 60, bitrate: 40, codec: 'h264', mode: 'quality' }
};

let opts = Object.assign(
  {
    maxSize: 1920,
    fps: 60,
    bitrate: 24,
    codec: 'h264',
    mode: 'fast',
    renderDriver: 'direct3d',
    audio: true,
    autoReconnect: true,
    awake: true,
    off: false,
    touch: false,
    top: false,
    borderless: false,
    view: false,
    recQuality: 'match',
    recFormat: 'mkv',
    recAudio: true
  },
  (() => {
    try { return JSON.parse(localStorage.getItem('dzopts_v3') || localStorage.getItem('dzopts_v2') || '{}'); }
    catch { return {}; }
  })()
);

let savedIps = (() => {
  try { return JSON.parse(localStorage.getItem('dz_saved_ips') || '[]'); }
  catch { return []; }
})();

let last = { devices: [], usb: [], active: [], sessions: {}, appleEnv: null, airplay: {}, overlayActive: false };
let applyDebounce = null;
let detectInFlight = false;
let telemetryInFlight = false;

// Keymap editor state
let kmData = null;
let selectedBtnId = null;
let awaitingKeyBind = false;

function normalizeKeyCode(e) {
  const c = e.code || '';
  if (/^Key[A-Z]$/.test(c)) return c.slice(3);
  if (/^Digit[0-9]$/.test(c)) return c.slice(5);
  if (/^F([1-9]|1[0-2])$/.test(c)) return c;
  const map = {
    Space: 'SPACE', Tab: 'TAB', Enter: 'ENTER', Escape: 'ESC', Backspace: 'BACKSPACE',
    ShiftLeft: 'SHIFT', ShiftRight: 'RSHIFT', ControlLeft: 'CTRL', ControlRight: 'RCTRL',
    AltLeft: 'ALT', AltRight: 'RALT', CapsLock: 'CAPSLOCK', Backquote: '~',
    ArrowUp: 'UP', ArrowDown: 'DOWN', ArrowLeft: 'LEFT', ArrowRight: 'RIGHT'
  };
  return map[c] || (e.key ? e.key.toUpperCase() : '?');
}

function toast(msg, ms = 3400) {
  const t = $('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast.h);
  toast.h = setTimeout(() => t.classList.remove('show'), ms);
}

function saveOpts() {
  try { localStorage.setItem('dzopts_v3', JSON.stringify(opts)); } catch { /* ignore */ }
}

function formatBytes(b) {
  if (!b) return '0 B';
  const u = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return `${b.toFixed(i ? 1 : 0)} ${u[i]}`;
}

function formatDuration(ms) {
  const sec = Math.max(0, Math.floor(ms / 1000));
  const m = String(Math.floor(sec / 60)).padStart(2, '0');
  const s = String(sec % 60).padStart(2, '0');
  return `${m}:${s}`;
}

// ---------- Navigation Tabs ----------
function switchTab(name) {
  document.querySelectorAll('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.tab').forEach((s) => s.classList.toggle('active', s.id === `tab-${name}`));
  if (name === 'quality') loadRecordings();
  if (name === 'iphone') refreshAppleEnv();
  if (name === 'health') runHealthCheck();
  if (name === 'gaming') renderKeymapEditor();
}

$('nav').addEventListener('click', (e) => {
  const b = e.target.closest('.nav-item[data-tab]');
  if (b) switchTab(b.dataset.tab);
});

document.addEventListener('click', (e) => {
  const go = e.target.closest('[data-goto]');
  if (go) switchTab(go.dataset.goto);
});

// ---------- Seamless Live Quality Hot-Swap ----------
function scheduleLiveApply() {
  if (!last.active || !last.active.length) return;
  const badge = $('liveApplyBadge');
  if (badge) badge.textContent = '⏳ جارٍ تطبيق الجودة بسلاسة…';
  clearTimeout(applyDebounce);
  applyDebounce = setTimeout(async () => {
    for (const serial of last.active) {
      const r = await call('stream:apply', serial, opts);
      if (r && r.ok) toast('⚡ تم تحديث جودة البث بسلاسة');
      else if (r && r.msg) toast('⚠️ ' + r.msg, 4500);
    }
    if (badge) badge.textContent = '✅ مطبّق على البث المباشر';
  }, 380);
}

function renderSegBlock(keys) {
  return keys
    .map((k) => {
      const [title, items] = SEG[k];
      return `<div class="seg"><label>${title}</label><div class="opts">${items
        .map(([t, v]) => `<button data-k="${k}" data-v="${v}" class="${opts[k] === v ? 'on' : ''}">${t}</button>`)
        .join('')}</div></div>`;
    })
    .join('');
}

function drawSettings() {
  $('segs').innerHTML = renderSegBlock(Object.keys(SEG));
  $('quickSegs').innerHTML = renderSegBlock(QUICK_SEG_KEYS);
  $('togs').innerHTML = TOG.map(
    ([k, t]) => `<div class="tog ${opts[k] ? 'on' : ''}" data-t="${k}"><span>${t}</span><span class="sw"></span></div>`
  ).join('');

  $('recQuality').value = opts.recQuality || 'match';
  $('recFormat').value = opts.recFormat || 'mkv';
  $('togRecAudio').classList.toggle('on', Boolean(opts.recAudio));
}

function handleSegClick(e) {
  const b = e.target.closest('button[data-k]');
  if (!b) return;
  const k = b.dataset.k;
  const raw = b.dataset.v;
  opts[k] = typeof SEG[k][1][0][1] === 'number' ? Number(raw) : raw;
  saveOpts();
  drawSettings();
  scheduleLiveApply();
}

$('segs').addEventListener('click', handleSegClick);
$('quickSegs').addEventListener('click', handleSegClick);

$('togs').addEventListener('click', (e) => {
  const t = e.target.closest('.tog');
  if (!t) return;
  opts[t.dataset.t] = !opts[t.dataset.t];
  saveOpts();
  drawSettings();
  scheduleLiveApply();
});

function applyPreset(pKey) {
  if (!PRESETS[pKey]) return;
  Object.assign(opts, PRESETS[pKey]);
  saveOpts();
  drawSettings();
  toast('⚡ تم تطبيق نمط الجودة');
  scheduleLiveApply();
}

$('mainPresets').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-p]');
  if (b) applyPreset(b.dataset.p);
});
$('sidePresets').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-p]');
  if (b) applyPreset(b.dataset.p);
});

$('recQuality').onchange = () => { opts.recQuality = $('recQuality').value; saveOpts(); toast('تم حفظ جودة التسجيل'); };
$('recFormat').onchange = () => { opts.recFormat = $('recFormat').value; saveOpts(); toast('تم حفظ صيغة التسجيل'); };
$('togRecAudio').onclick = () => { opts.recAudio = !opts.recAudio; saveOpts(); drawSettings(); };

// ---------- Recordings List ----------
async function loadRecordings() {
  const r = await call('recordings:list');
  const box = $('recList');
  if (!r || !r.files || !r.files.length) {
    box.innerHTML = '<p class="muted">لا توجد تسجيلات بعد. ابدأ البث واضغط زر «⏺ تسجيل» في بطاقة الجهاز.</p>';
    return;
  }
  box.innerHTML = r.files
    .map(
      (f) => `<div class="rec-item">
        <div class="rec-info">
          <div class="rec-name">${esc(f.name)}</div>
          <div class="rec-meta">${formatBytes(f.size)} • ${new Date(f.mtime).toLocaleString('ar-DZ')}</div>
        </div>
        <div class="rec-acts">
          <button class="btn-secondary btn-sm" data-openfile="${esc(f.path)}">▶ تشغيل</button>
          <button class="btn-ghost btn-sm" data-revealfile="${esc(f.path)}">📂</button>
        </div>
      </div>`
    )
    .join('');
}

$('bRefreshRecs').onclick = loadRecordings;
$('bOpenRecDir').onclick = () => call('folder:open', 'video');
$('bShots').onclick = () => call('folder:open', 'pic');
$('bVids').onclick = () => call('folder:open', 'video');

// ---------- Live Recording Timer ----------
function updateRecBanner() {
  const recEntry = Object.values(last.sessions || {}).find((s) => s.recording && s.recStart);
  const banner = $('recBanner');
  if (recEntry) {
    banner.classList.remove('hidden');
    $('recTimer').textContent = formatDuration(Date.now() - recEntry.recStart);
  } else {
    banner.classList.add('hidden');
  }
}
setInterval(updateRecBanner, 1000);

// ---------- Live Telemetry (Ping / Latency / Memory / Mouse Lock) ----------
async function pollTelemetry() {
  if (telemetryInFlight) return;
  telemetryInFlight = true;
  try {
    const primarySerial = (last.active && last.active[0]) || (last.devices && last.devices[0] && last.devices[0].serial) || null;
    const t = await call('net:telemetry', primarySerial);
    if (t && t.ok) {
      const pingEl = $('telPing');
      if (t.latencyMs != null) {
        pingEl.textContent = `${t.latencyMs} ms`;
        pingEl.className = 'tel-item ' + (t.latencyMs <= 35 ? 'good' : 'warn');
      } else {
        pingEl.textContent = '-- ms';
        pingEl.className = 'tel-item';
      }
      $('telMem').textContent = `${t.rssMB || '--'} MB`;
      updateMouseTelemetryBadge(t.mouseLocked, t.freeLook);
    }
  } catch { /* ignore */ }
  finally { telemetryInFlight = false; }
}

function updateMouseTelemetryBadge(locked, freeLook) {
  const el = $('telMouse');
  if (!el) return;
  if (freeLook) {
    el.textContent = '👁 نظرة حرة';
    el.className = 'tel-item warn';
  } else if (locked) {
    el.textContent = '🔒 360° مقفل';
    el.className = 'tel-item locked';
  } else {
    el.textContent = '🔓 فأرة حرة';
    el.className = 'tel-item';
  }
}

// ---------- Devices & Main Render ----------
function render(d) {
  if (!d || !d.ok) return;
  last = d;
  const readyDevs = (d.devices || []).filter((x) => x.state === 'device');
  const st = $('adbState');
  st.className = 'status-pill ok';
  st.innerHTML = `<i class="dot"></i><span>${readyDevs.length} جهاز جاهز</span>`;
  $('navDevCount').textContent = String(readyDevs.length);
  $('navAirDot').classList.toggle('on', Boolean(d.airplay && d.airplay.running));
  $('navKmDot').classList.toggle('on', Boolean(d.overlayActive));

  $('empty').style.display = readyDevs.length ? 'none' : 'block';

  const alerts = [];
  const androidUsb = (d.usb || []).filter((u) => u.kind === 'android');
  const usbAdb = (d.devices || []).filter((x) => !x.wifi);
  const unauth = (d.devices || []).filter((x) => x.state === 'unauthorized');
  const off = (d.devices || []).filter((x) => x.state === 'offline');

  if (androidUsb.length && !usbAdb.length) {
    const u = androidUsb[0];
    if (u.issue) {
      alerts.push(
        `<div class="alert err">⚠️ تم اكتشاف هاتف <b>${esc(u.vendor)}</b> عبر USB لكن <b>التعريفات بحاجة للتثبيت</b>.<div class="btn-row"><button class="btn-primary btn-sm" data-a="fix">🛠 تثبيت التعريفات تلقائياً</button><button class="btn-ghost btn-sm" data-a="oem" data-v="${esc(u.vendor)}">🌐 تعريف ${esc(u.vendor)} الرسمي</button></div></div>`
      );
    } else {
      alerts.push(
        `<div class="alert">🔌 تم اكتشاف هاتف <b>${esc(u.vendor)}</b> عبر USB لكنه لم يظهر في البث بعد. فعّل <b>تصحيح USB</b> واختر وضع «نقل الملفات» ثم اقبل رسالة السماح.<div class="btn-row"><button class="btn-secondary btn-sm" data-goto="health">📖 كيف أفعّل تصحيح USB؟</button><button class="btn-ghost btn-sm" data-a="fix">🛠 إصلاح التعريفات</button><button class="btn-ghost btn-sm" data-a="restart">↻ إعادة تشغيل ADB</button></div></div>`
      );
    }
  }
  unauth.forEach(() =>
    alerts.push('<div class="alert">🔐 الهاتف متصل لكن <b>لم تتم الموافقة على التصحيح</b>. انظر لشاشة الهاتف واضغط «السماح دائماً».</div>')
  );
  off.forEach(() =>
    alerts.push('<div class="alert">⚠️ جهاز في حالة «غير متصل». افصل الكابل وأعد توصيله أو أعد تشغيل ADB.</div>')
  );
  $('alerts').innerHTML = alerts.join('');

  $('list').innerHTML = readyDevs
    .map((x) => {
      const i = x.info || {};
      const live = (d.active || []).includes(x.serial);
      const sess = (d.sessions && d.sessions[x.serial]) || {};
      const isRec = Boolean(sess.recording);
      const isOverlay = d.overlayActive && d.overlaySerial === x.serial;

      return `<div class="card dev-card ${live ? 'live' : ''}">
        <div class="dev-top">
          <div class="dev-icon"></div>
          <div class="dev-meta">
            <div class="dev-name">${esc(i.name || x.serial)}</div>
            <div class="dev-tags">
              <span class="tag ${x.wifi ? 'wifi' : ''}">${x.wifi ? '📶 واي فاي' : '🔌 USB'}</span>
              ${live ? '<span class="tag live">● يبثّ الآن</span>' : ''}
              ${isRec ? '<span class="tag rec">⏺ يُسجّل</span>' : ''}
              ${isOverlay ? '<span class="tag">🎮 تحكم 360° نشط</span>' : ''}
            </div>
            <div class="dev-specs">
              الطراز: ${esc(i.model || '-')} • أندرويد ${esc(i.android)} ${i.size ? '• ' + esc(i.size) : ''}${i.battery ? ' • 🔋 ' + esc(i.battery) + '%' : ''}
              <br><span dir="ltr">${esc(x.serial)}</span>
            </div>
          </div>
        </div>
        <div class="dev-actions">
          ${live
            ? `<button class="btn-danger" data-a="stop" data-s="${esc(x.serial)}">⏹ إيقاف البث</button>`
            : `<button class="btn-primary" data-a="start" data-s="${esc(x.serial)}">▶ ابدأ البث</button>`}
          ${live
            ? (isRec
                ? `<button class="btn-danger" data-a="recstop" data-s="${esc(x.serial)}">⏹ إيقاف التسجيل</button>`
                : `<button class="btn-rec" data-a="recstart" data-s="${esc(x.serial)}">⏺ تسجيل الشاشة</button>`)
            : ''}
          ${live
            ? `<button class="btn-secondary" data-a="overlay" data-s="${esc(x.serial)}">${isOverlay ? '✏️ تعديل الأزرار' : '🎮 تحكم الألعاب 360°'}</button>`
            : ''}
          <button class="btn-ghost" data-a="shot" data-s="${esc(x.serial)}">📸 لقطة</button>
          ${x.wifi
            ? `<button class="btn-ghost" data-a="disc" data-s="${esc(x.serial)}">⛔ فصل</button>`
            : `<button class="btn-ghost" data-a="wifi" data-s="${esc(x.serial)}">📶 تحويل لاسلكي</button>`}
        </div>
      </div>`;
    })
    .join('');

  $('bEditOverlay').classList.toggle('hidden', !d.overlayActive);
  $('bCloseOverlay').classList.toggle('hidden', !d.overlayActive);

  renderIosUsbBox(d.usb || [], d.appleEnv);
  updateRecBanner();
  updateMouseTelemetryBadge(d.mouseLocked, d.freeLook);
}

// ---------- Apple / iPhone & AirPlay ----------
function renderIosUsbBox(usbList, env) {
  const ios = (usbList || []).filter((u) => u.kind === 'ios');
  const box = $('iosUsbBox');
  if (!box) return;
  if (ios.length) {
    box.innerHTML = `<div class="check-item" style="border-color:rgba(16,185,129,.45)">
      <span>📱 تم اكتشاف <b>${esc(ios[0].name || 'Apple iPhone')}</b> عبر USB</span>
      <span class="${ios[0].issue ? 'st-warn' : 'st-ok'}">${ios[0].issue ? '⚠️ يحتاج تعريف' : '✅ متصل بنجاح'}</span>
    </div>`;
  } else {
    box.innerHTML = '<div class="check-item"><span>📱 اتصال USB للآيفون</span><span class="muted">غير موصول حالياً (AirPlay يعمل بدون كابل)</span></div>';
  }
  if (env) renderAppleChecks(env);
}

function renderAppleChecks(env) {
  const items = [
    ['تعريفات Apple (usbaapl64 / Apple Devices / iTunes)', env.driverInstalled, env.driverInstalled ? '✅ مثبتة وجاهزة' : '❌ غير مكتشفة'],
    ['خدمة Bonjour (ضرورية لظهور AirPlay على الآيفون)', env.bonjourRunning, env.bonjourRunning ? '✅ تعمل' : (env.bonjourInstalled ? '⚠️ مثبتة لكنها متوقفة' : '❌ غير مثبتة')],
    ['محرك AirPlay (uxplay.exe)', env.uxplayFound, env.uxplayFound ? '✅ موجود وجاهز' : '⚠️ غير موجود في bin/uxplay'],
    ['قواعد جدار حماية ويندوز (منافذ AirPlay و mDNS)', env.firewallRule, env.firewallRule ? '✅ مفتوحة' : '⚠️ يُنصح بفتحها بضغطة زر']
  ];
  $('appleChecks').innerHTML = items
    .map(([label, ok, txt]) => `<div class="check-item"><span>${label}</span><span class="${ok ? 'st-ok' : 'st-warn'}">${txt}</span></div>`)
    .join('');

  if (env.ips && env.ips.length) {
    $('pcIps').innerHTML = `🌐 عنوان الحاسوب على الشبكة المحلية: <b dir="ltr">${env.ips.map((x) => x.address).join(' • ')}</b>`;
  }
  updateAirplayUI({ running: env.airplayRunning, connected: env.airplayConnected });
}

function updateAirplayUI(st) {
  const running = Boolean(st && st.running);
  const connected = Boolean(st && st.connected);
  const badge = $('airStatusBadge');
  badge.className = 'badge ' + (connected ? 'live' : running ? 'ok' : '');
  badge.textContent = connected ? '● آيفون يبثّ الآن' : running ? '📡 في انتظار اتصال الآيفون…' : 'متوقف';
  $('bAirStart').classList.toggle('hidden', running);
  $('bAirStop').classList.toggle('hidden', !running);
  $('navAirDot').classList.toggle('on', running);
  if (st && st.logs && st.logs.length) {
    $('airLogs').textContent = st.logs.join('\n');
  }
}

async function refreshAppleEnv() {
  const env = await call('apple:env');
  if (env) renderAppleChecks(env);
}

$('airName').oninput = () => { $('airNamePreview').textContent = $('airName').value || 'DZ Mirror'; };
$('bRefreshApple').onclick = async () => { await refreshAppleEnv(); toast('تم تحديث فحص بيئة Apple'); };
$('bFixAppleDrv').onclick = async () => { const r = await call('driver:fix', 'ios'); toast(r.msg || '', 5500); };
$('bFixBonjour').onclick = async () => { const r = await call('apple:bonjour'); toast(r.msg || '', 5000); };
$('bFixFirewall').onclick = async () => {
  toast('وافق على نافذة المسؤول لفتح منافذ AirPlay…', 5000);
  const r = await call('apple:firewall');
  toast(r.msg || '', 5500);
  refreshAppleEnv();
};
$('bAirPick').onclick = async () => {
  const r = await call('apple:airplay:pick');
  if (r.ok) { toast('✅ تم تحديد uxplay.exe بنجاح'); refreshAppleEnv(); }
};
$('bAirStart').onclick = async () => {
  const r = await call('apple:airplay:start', {
    name: $('airName').value,
    resolution: $('airRes').value,
    fps: Number($('airFps').value),
    audio: $('airAudio').value === '1'
  });
  toast(r.msg || '', 6500);
  if (r.ok) updateAirplayUI({ running: true, connected: false });
};
$('bAirStop').onclick = async () => {
  await call('apple:airplay:stop');
  updateAirplayUI({ running: false, connected: false });
  toast('تم إيقاف مستقبِل AirPlay');
};

if (window.api) window.api.onAirplayState((st) => updateAirplayUI(st));

// ---------- Global Device Card & File Actions ----------
document.addEventListener('click', async (e) => {
  const openF = e.target.closest('[data-openfile]');
  if (openF) return call('file:open', openF.dataset.openfile);
  const revF = e.target.closest('[data-revealfile]');
  if (revF) return call('file:reveal', revF.dataset.revealfile);

  const mbind = e.target.closest('[data-mbind]');
  if (mbind && selectedBtnId) {
    const prof = getActiveProfile();
    const btn = prof && prof.buttons.find((x) => x.id === selectedBtnId);
    if (btn) {
      btn.key = mbind.dataset.mbind;
      awaitingKeyBind = false;
      await persistKeymaps();
      renderKeymapEditor();
      toast(`✅ تم ربط الزر بزر الفأرة ${btn.key}`);
    }
    return;
  }

  const b = e.target.closest('button[data-a]');
  if (!b) return;
  const a = b.dataset.a;
  const s = b.dataset.s;
  const dev = (last.devices || []).find((x) => x.serial === s);
  const info = (dev && dev.info) || {};
  b.disabled = true;

  try {
    if (a === 'start') {
      const r = await call('stream:start', s, Object.assign({}, opts, { title: info.name, sdk: info.sdk || 0 }));
      toast(r.ok ? '▶ بدأ البث بسلاسة… ستظهر النافذة الآن' : '⚠️ ' + r.msg, 4500);
    } else if (a === 'stop') {
      await call('stream:stop', s);
      toast('⏹ تم إيقاف البث');
    } else if (a === 'recstart') {
      const r = await call('record:start', s, {
        quality: opts.recQuality || 'match',
        format: opts.recFormat || 'mkv',
        audio: opts.recAudio !== false
      });
      toast(r.ok ? '⏺ بدأ تسجيل الشاشة بالجودة المختارة' : '⚠️ ' + r.msg, 4500);
    } else if (a === 'recstop') {
      const r = await call('record:stop', s);
      toast(r.ok ? '✅ ' + r.msg : '⚠️ ' + (r.msg || 'فشل إيقاف التسجيل'), 5000);
      loadRecordings();
    } else if (a === 'overlay') {
      if (last.overlayActive && last.overlaySerial === s) {
        await call('keymap:overlay:mode', true);
        toast('✏️ يمكنك الآن سحب الأزرار مباشرة فوق اللعبة');
      } else {
        await openOverlayForSerial(s);
      }
    } else if (a === 'shot') {
      const r = await call('shot', s, info.name);
      toast(r.ok ? '📸 حُفظت اللقطة في مجلد الصور/DZMirror' : '⚠️ فشل أخذ اللقطة');
    } else if (a === 'wifi') {
      toast('جارٍ التحويل للاتصال اللاسلكي…', 6000);
      const r = await call('wifi:enable', s);
      if (r.ok && r.ip) saveRecentIp(`${r.ip}:5555`);
      toast(r.ok ? '✅ متصل لاسلكياً! يمكنك فصل الكابل الآن' : '⚠️ ' + (r.msg || 'فشل'), 5500);
    } else if (a === 'disc') {
      await call('wifi:disconnect', s);
      toast('تم فصل الاتصال اللاسلكي');
    } else if (a === 'fix') {
      toast('وافق على نافذة المسؤول لتثبيت التعريفات…', 6000);
      const r = await call('driver:fix', 'android');
      toast(r.msg || '', 6000);
    } else if (a === 'oem') {
      await call('oem:open', b.dataset.v);
    } else if (a === 'restart') {
      await call('adb:restart');
      toast('↻ تمت إعادة تشغيل خدمة ADB');
    }
  } finally {
    b.disabled = false;
  }
});

$('bRestartAdb').onclick = async () => {
  await call('adb:restart');
  toast('↻ تم تحديث اتصال ADB');
};

// ---------- Wi-Fi Tab ----------
function saveRecentIp(host) {
  if (!host) return;
  savedIps = [host, ...savedIps.filter((x) => x !== host)].slice(0, 6);
  localStorage.setItem('dz_saved_ips', JSON.stringify(savedIps));
  renderSavedIps();
}
function renderSavedIps() {
  $('savedIps').innerHTML = savedIps.length
    ? savedIps.map((h) => `<span class="ip-chip" dir="ltr" data-ip="${esc(h)}">${esc(h)}</span>`).join('')
    : '';
}
$('savedIps').addEventListener('click', (e) => {
  const c = e.target.closest('.ip-chip');
  if (c) { $('ip').value = c.dataset.ip; $('bConnect').click(); }
});
$('bConnect').onclick = async () => {
  const host = $('ip').value.trim();
  const r = await call('wifi:connect', host);
  if (r.ok) saveRecentIp(host.includes(':') ? host : `${host}:5555`);
  toast(r.ok ? '✅ تم الاتصال بالهاتف لاسلكياً' : '⚠️ ' + (r.msg || 'فشل الاتصال'), 4500);
};
$('bPair').onclick = async () => {
  const r = await call('wifi:pair', $('pairHost').value, $('pairCode').value);
  toast(r.ok ? '✅ تم الإقران بنجاح! اتصل الآن بالعنوان الظاهر في شاشة التصحيح اللاسلكي' : '⚠️ ' + (r.msg || 'فشل الإقران'), 6000);
};

// ---------- Game Keymapping & 360° Mouse Studio ----------
async function initKeymaps() {
  const r = await call('keymap:load');
  if (r && r.ok && r.data) {
    kmData = r.data;
    renderKeymapEditor();
  }
}

function getActiveProfile() {
  if (!kmData || !kmData.profiles || !kmData.profiles.length) return null;
  return kmData.profiles.find((p) => p.id === kmData.activeProfileId) || kmData.profiles[0];
}

function getActiveMouse() {
  const prof = getActiveProfile();
  if (prof && prof.mouse) return prof.mouse;
  if (!kmData.mouse) kmData.mouse = {};
  return kmData.mouse;
}

async function persistKeymaps() {
  if (!kmData) return;
  const r = await call('keymap:save', kmData);
  if (r && r.ok && r.data) kmData = r.data;
}

function renderMousePanel() {
  if (!kmData) return;
  const m = getActiveMouse();
  $('mSensX').value = Math.round((m.sensX ?? 1.0) * 100);
  $('valSensX').textContent = (m.sensX ?? 1.0).toFixed(2) + 'x';
  $('mSensY').value = Math.round((m.sensY ?? 1.0) * 100);
  $('valSensY').textContent = (m.sensY ?? 1.0).toFixed(2) + 'x';
  $('mScopeSens').value = Math.round((m.scopeSens ?? 0.65) * 100);
  $('valScopeSens').textContent = (m.scopeSens ?? 0.65).toFixed(2) + 'x';
  $('mDpi').value = Math.round((m.dpiScale ?? 1.0) * 100);
  $('valDpi').textContent = (m.dpiScale ?? 1.0).toFixed(2) + 'x';
  $('mSmooth').value = Math.round((m.smoothing ?? 0.22) * 100);
  $('valSmooth').textContent = Math.round((m.smoothing ?? 0.22) * 100) + '%';

  $('mLockKey').value = m.lockKey || 'CTRL';
  $('mFreeLookKey').value = m.freeLookKey || 'ALT';
  $('mAdsMode').value = m.adsMode || 'hold';

  $('togMouseEnabled').classList.toggle('on', m.enabled !== false);
  $('togInvertY').classList.toggle('on', Boolean(m.invertY));
  $('togAutoUnlock').classList.toggle('on', m.autoUnlockOnBag !== false);
}

function renderKeymapEditor() {
  if (!kmData) return;
  const prof = getActiveProfile();
  if (!prof) return;

  $('kmProfile').innerHTML = kmData.profiles
    .map((p) => `<option value="${esc(p.id)}" ${p.id === prof.id ? 'selected' : ''}>${esc(p.icon || '🎮')} ${esc(p.name)}</option>`)
    .join('');

  const pct = Math.round((kmData.opacity ?? 0.72) * 100);
  $('kmOpacity').value = pct;
  $('kmOpacityVal').textContent = pct + '%';
  $('togKmEnabled').classList.toggle('on', kmData.enabled !== false);
  $('togKmVisible').classList.toggle('on', kmData.visible !== false);

  const box = $('kmButtons');
  box.innerHTML = '';
  const alpha = kmData.visible === false ? 0.15 : Math.max(0.22, kmData.opacity ?? 0.72);

  for (const b of prof.buttons || []) {
    const el = document.createElement('div');
    const isJoy = b.type === 'joystick';
    const isAim = b.type === 'aim';
    const isEye = b.type === 'freelook';

    let sz = Math.max(30, b.size || 46);
    if (isJoy) sz = Math.max(78, Math.round((b.radius || 11) * 7.2));
    else if (isAim) sz = Math.max(66, Math.round((b.radius || 22) * 3.1));

    let cls = 'km-btn';
    if (isJoy) cls += ' joy';
    else if (isAim) cls += ' aim';
    else if (isEye) cls += ' freelook';
    else if (b.action === 'fire') cls += ' fire';
    else if (b.action === 'ads') cls += ' ads';
    if (selectedBtnId === b.id) cls += ' selected';

    el.className = cls;
    el.style.left = b.x + '%';
    el.style.top = b.y + '%';
    el.style.width = sz + 'px';
    el.style.height = sz + 'px';
    el.style.opacity = String(alpha);
    el.innerHTML = `<b>${esc(isJoy ? 'WASD' : (b.key || '?'))}</b><span>${esc(b.label || '')}</span>`;

    el.addEventListener('mousedown', (ev) => {
      ev.preventDefault();
      selectedBtnId = b.id;
      awaitingKeyBind = false;
      renderInspector();
      document.querySelectorAll('.km-btn').forEach((x) => x.classList.remove('selected'));
      el.classList.add('selected');

      const rect = $('kmCanvas').getBoundingClientRect();
      const onMove = (m) => {
        b.x = Math.round(Math.max(3, Math.min(97, ((m.clientX - rect.left) / rect.width) * 100)) * 10) / 10;
        b.y = Math.round(Math.max(3, Math.min(97, ((m.clientY - rect.top) / rect.height) * 100)) * 10) / 10;
        el.style.left = b.x + '%';
        el.style.top = b.y + '%';
      };
      const onUp = () => {
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
        persistKeymaps();
      };
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
    });

    box.appendChild(el);
  }
  renderInspector();
  renderMousePanel();
}

function renderInspector() {
  const prof = getActiveProfile();
  const btn = prof && (prof.buttons || []).find((x) => x.id === selectedBtnId);
  if (!btn) {
    $('inspEmpty').classList.remove('hidden');
    $('inspForm').classList.add('hidden');
    return;
  }
  $('inspEmpty').classList.add('hidden');
  $('inspForm').classList.remove('hidden');
  $('inspLabel').value = btn.label || '';

  const isJoy = btn.type === 'joystick';
  const isAim = btn.type === 'aim';
  const isEye = btn.type === 'freelook';
  const isStd = !isJoy && !isAim && !isEye;

  $('inspTypeWrap').classList.toggle('hidden', !isStd);
  $('inspKeyWrap').classList.toggle('hidden', isJoy);
  $('inspSizeWrap').classList.toggle('hidden', isJoy || isAim);
  $('inspJoyWrap').classList.toggle('hidden', !isJoy);
  $('inspAimWrap').classList.toggle('hidden', !isAim);

  if (isStd) {
    $('inspType').value = ['click', 'hold', 'dblclick', 'toggle'].includes(btn.type) ? btn.type : 'click';
  }
  if (!isJoy) {
    $('inspKey').value = awaitingKeyBind ? 'اضغط أي مفتاح الآن…' : (btn.key || '');
  }
  if (!isJoy && !isAim) {
    $('inspSize').value = btn.size || 46;
    $('inspSizeVal').textContent = (btn.size || 46) + 'px';
  }
  if (isJoy) {
    $('inspJoyRad').value = btn.radius || 11;
    $('inspJoyRadVal').textContent = (btn.radius || 11) + '%';
    $('inspJoySprint').value = btn.sprintRadius || 19;
    $('inspJoySprintVal').textContent = (btn.sprintRadius || 19) + '%';
    $('inspJoySens').value = Math.round((btn.sensitivity ?? 1.0) * 100);
    $('inspJoySensVal').textContent = (btn.sensitivity ?? 1.0).toFixed(1) + 'x';
    $('togAutoSprint').classList.toggle('on', btn.autoSprint !== false);
  }
  if (isAim) {
    $('inspAimRad').value = btn.radius || 22;
    $('inspAimRadVal').textContent = (btn.radius || 22) + '%';
  }
}

// Mouse 360 panel bindings
function bindMouseRange(id, prop, div, fmt) {
  const el = $(id);
  el.oninput = () => {
    const m = getActiveMouse();
    m[prop] = Number(el.value) / div;
    renderMousePanel();
  };
  el.onchange = () => persistKeymaps();
}
bindMouseRange('mSensX', 'sensX', 100);
bindMouseRange('mSensY', 'sensY', 100);
bindMouseRange('mScopeSens', 'scopeSens', 100);
bindMouseRange('mDpi', 'dpiScale', 100);
bindMouseRange('mSmooth', 'smoothing', 100);

$('mLockKey').onchange = () => { getActiveMouse().lockKey = $('mLockKey').value; persistKeymaps(); };
$('mFreeLookKey').onchange = () => { getActiveMouse().freeLookKey = $('mFreeLookKey').value; persistKeymaps(); };
$('mAdsMode').onchange = () => { getActiveMouse().adsMode = $('mAdsMode').value; persistKeymaps(); };

$('togMouseEnabled').onclick = () => { const m = getActiveMouse(); m.enabled = !(m.enabled !== false); persistKeymaps(); renderMousePanel(); };
$('togInvertY').onclick = () => { const m = getActiveMouse(); m.invertY = !m.invertY; persistKeymaps(); renderMousePanel(); };
$('togAutoUnlock').onclick = () => { const m = getActiveMouse(); m.autoUnlockOnBag = !(m.autoUnlockOnBag !== false); persistKeymaps(); renderMousePanel(); };

// Profile & Canvas actions
$('kmProfile').onchange = async () => {
  kmData.activeProfileId = $('kmProfile').value;
  selectedBtnId = null;
  await persistKeymaps();
  renderKeymapEditor();
  toast('تم تبديل ملف أزرار اللعبة');
};

$('kmOpacity').oninput = () => {
  const v = Number($('kmOpacity').value);
  $('kmOpacityVal').textContent = v + '%';
  kmData.opacity = v / 100;
  renderKeymapEditor();
};
$('kmOpacity').onchange = () => persistKeymaps();

$('togKmEnabled').onclick = async () => { kmData.enabled = !(kmData.enabled !== false); await persistKeymaps(); renderKeymapEditor(); };
$('togKmVisible').onclick = async () => { kmData.visible = !(kmData.visible !== false); await persistKeymaps(); renderKeymapEditor(); };

$('bCanvasAddTap').onclick = async () => {
  const prof = getActiveProfile();
  if (!prof) return;
  const id = 'btn_' + Date.now().toString(36);
  prof.buttons.push({ id, type: 'click', label: 'زر مخصص', key: 'G', x: 50, y: 50, size: 46 });
  selectedBtnId = id;
  await persistKeymaps();
  renderKeymapEditor();
  toast('➕ تمت إضافة زر جديد، اسحبه للمكان المطلوب');
};

$('bCanvasAddJoy').onclick = async () => {
  const prof = getActiveProfile();
  if (!prof) return;
  if (prof.buttons.some((b) => b.type === 'joystick')) return toast('عصا الحركة WASD موجودة بالفعل');
  prof.buttons.push({ id: 'joy1', type: 'joystick', label: 'حركة WASD', up: 'W', down: 'S', left: 'A', right: 'D', sprint: 'SHIFT', x: 16, y: 74, radius: 11, sprintRadius: 19, autoSprint: true, sensitivity: 1.0 });
  selectedBtnId = 'joy1';
  await persistKeymaps();
  renderKeymapEditor();
};

$('bCanvasAddAim').onclick = async () => {
  const prof = getActiveProfile();
  if (!prof) return;
  if (prof.buttons.some((b) => b.type === 'aim')) return toast('منطقة الكاميرا 360° موجودة بالفعل');
  prof.buttons.push({ id: 'aim1', type: 'aim', label: 'كاميرا 360°', key: 'CTRL', x: 66, y: 46, radius: 22 });
  selectedBtnId = 'aim1';
  await persistKeymaps();
  renderKeymapEditor();
};

$('bCanvasAddEye').onclick = async () => {
  const prof = getActiveProfile();
  if (!prof) return;
  if (prof.buttons.some((b) => b.type === 'freelook')) return toast('زر النظرة الحرة موجود بالفعل');
  prof.buttons.push({ id: 'eye1', type: 'freelook', label: 'نظرة حرة', key: 'ALT', x: 81, y: 27, size: 42 });
  selectedBtnId = 'eye1';
  await persistKeymaps();
  renderKeymapEditor();
};

$('bNewProfile').onclick = async () => {
  const name = 'ملف مخصص ' + (kmData.profiles.length + 1);
  const id = 'custom_' + Date.now().toString(36);
  kmData.profiles.push({
    id, name, icon: '⭐',
    mouse: Object.assign({}, getActiveMouse()),
    buttons: [
      { id: 'joy1', type: 'joystick', label: 'حركة WASD', up: 'W', down: 'S', left: 'A', right: 'D', sprint: 'SHIFT', x: 16, y: 74, radius: 11, sprintRadius: 19, autoSprint: true, sensitivity: 1.0 },
      { id: 'aim1', type: 'aim', label: 'كاميرا 360°', key: 'CTRL', x: 66, y: 46, radius: 22 },
      { id: 'fire', type: 'hold', action: 'fire', label: 'إطلاق', key: 'LMB', x: 86, y: 72, size: 54 },
      { id: 'scope', type: 'hold', action: 'ads', label: 'منظار', key: 'RMB', x: 92, y: 50, size: 46 },
      { id: 'jump', type: 'click', label: 'قفز', key: 'SPACE', x: 91, y: 84, size: 46 }
    ]
  });
  kmData.activeProfileId = id;
  selectedBtnId = null;
  await persistKeymaps();
  renderKeymapEditor();
  toast('✅ تم إنشاء ملف تحكم جديد');
};

$('bResetProfile').onclick = async () => {
  const prof = getActiveProfile();
  const r = await call('keymap:reset', prof ? prof.id : null);
  if (r && r.ok && r.data) {
    kmData = r.data;
    selectedBtnId = null;
    renderKeymapEditor();
    toast('↺ تمت استعادة الإعدادات الافتراضية بنجاح');
  }
};

$('bExportProfile').onclick = async () => {
  const r = await call('keymap:export', kmData);
  if (r && r.ok) toast('📤 تم تصدير ملف إعدادات التحكم بنجاح');
  else if (r && !r.canceled) toast('⚠️ فشل التصدير: ' + (r.msg || ''));
};

$('bImportProfile').onclick = async () => {
  const r = await call('keymap:import');
  if (r && r.ok && r.data) {
    kmData = r.data;
    selectedBtnId = null;
    renderKeymapEditor();
    toast('📥 تم استيراد ملف إعدادات التحكم بنجاح');
  } else if (r && !r.canceled) {
    toast('⚠️ ' + (r.msg || 'فشل الاستيراد'));
  }
};

// Inspector bindings
$('inspLabel').oninput = () => {
  const btn = (getActiveProfile()?.buttons || []).find((x) => x.id === selectedBtnId);
  if (btn) { btn.label = $('inspLabel').value; renderKeymapEditor(); }
};
$('inspLabel').onchange = () => persistKeymaps();

$('inspType').onchange = () => {
  const btn = (getActiveProfile()?.buttons || []).find((x) => x.id === selectedBtnId);
  if (btn) { btn.type = $('inspType').value; persistKeymaps(); }
};

$('inspSize').oninput = () => {
  const btn = (getActiveProfile()?.buttons || []).find((x) => x.id === selectedBtnId);
  if (btn) { btn.size = Number($('inspSize').value); $('inspSizeVal').textContent = btn.size + 'px'; renderKeymapEditor(); }
};
$('inspSize').onchange = () => persistKeymaps();

$('inspJoyRad').oninput = () => {
  const btn = (getActiveProfile()?.buttons || []).find((x) => x.id === selectedBtnId);
  if (btn) { btn.radius = Number($('inspJoyRad').value); $('inspJoyRadVal').textContent = btn.radius + '%'; renderKeymapEditor(); }
};
$('inspJoyRad').onchange = () => persistKeymaps();

$('inspJoySprint').oninput = () => {
  const btn = (getActiveProfile()?.buttons || []).find((x) => x.id === selectedBtnId);
  if (btn) { btn.sprintRadius = Number($('inspJoySprint').value); $('inspJoySprintVal').textContent = btn.sprintRadius + '%'; }
};
$('inspJoySprint').onchange = () => persistKeymaps();

$('inspJoySens').oninput = () => {
  const btn = (getActiveProfile()?.buttons || []).find((x) => x.id === selectedBtnId);
  if (btn) { btn.sensitivity = Number($('inspJoySens').value) / 100; $('inspJoySensVal').textContent = btn.sensitivity.toFixed(1) + 'x'; }
};
$('inspJoySens').onchange = () => persistKeymaps();

$('togAutoSprint').onclick = () => {
  const btn = (getActiveProfile()?.buttons || []).find((x) => x.id === selectedBtnId);
  if (btn) { btn.autoSprint = !(btn.autoSprint !== false); persistKeymaps(); renderInspector(); }
};

$('inspAimRad').oninput = () => {
  const btn = (getActiveProfile()?.buttons || []).find((x) => x.id === selectedBtnId);
  if (btn) { btn.radius = Number($('inspAimRad').value); $('inspAimRadVal').textContent = btn.radius + '%'; renderKeymapEditor(); }
};
$('inspAimRad').onchange = () => persistKeymaps();

$('bBindKey').onclick = () => { awaitingKeyBind = true; renderInspector(); };

window.addEventListener('keydown', async (e) => {
  if (!awaitingKeyBind || !selectedBtnId) return;
  e.preventDefault();
  const btn = (getActiveProfile()?.buttons || []).find((x) => x.id === selectedBtnId);
  if (btn) {
    btn.key = normalizeKeyCode(e);
    awaitingKeyBind = false;
    await persistKeymaps();
    renderKeymapEditor();
    toast(`✅ تم ربط الزر بالمفتاح ${btn.key}`);
  }
});

$('bDelBtn').onclick = async () => {
  const prof = getActiveProfile();
  if (!prof || !selectedBtnId) return;
  prof.buttons = prof.buttons.filter((x) => x.id !== selectedBtnId);
  selectedBtnId = null;
  await persistKeymaps();
  renderKeymapEditor();
};

async function openOverlayForSerial(serial) {
  const prof = getActiveProfile();
  const r = await call('keymap:overlay:open', serial, {
    enabled: kmData ? kmData.enabled !== false : true,
    visible: kmData ? kmData.visible !== false : true,
    opacity: kmData ? (kmData.opacity ?? 0.72) : 0.72,
    editMode: false,
    activeProfileId: prof ? prof.id : 'pubg',
    mouse: getActiveMouse(),
    buttons: prof ? prof.buttons : []
  });
  toast(r.ok ? '🎮 تم تفعيل طبقة التحكم 360° (CTRL لقفل الفأرة • F9 للإخفاء)' : '⚠️ ' + r.msg, 5000);
}

$('bOpenOverlay').onclick = async () => {
  const serial = last.active && last.active[0];
  if (!serial) return toast('⚠️ ابدأ بث شاشة الهاتف أولاً من تبويب «الأجهزة والبث»', 4500);
  await openOverlayForSerial(serial);
};
$('bEditOverlay').onclick = async () => {
  await call('keymap:overlay:mode', true);
  toast('✏️ وضع التعديل المباشر مفعّل — اسحب الأزرار فوق اللعبة ثم اضغط حفظ');
};
$('bCloseOverlay').onclick = async () => {
  await call('keymap:overlay:close');
  toast('تم إغلاق طبقة أزرار الألعاب');
};

if (window.api) {
  window.api.onKeymapEvent((ev) => {
    if (!ev) return;
    if (ev.type === 'visibility' && kmData) {
      kmData.visible = ev.visible;
      renderKeymapEditor();
    } else if (ev.type === 'mouselock') {
      updateMouseTelemetryBadge(ev.locked, false);
    } else if (ev.type === 'freelook') {
      updateMouseTelemetryBadge(true, ev.active);
    } else if (ev.type === 'error' && ev.msg) {
      toast('⚠️ ' + ev.msg, 5500);
    }
  });

  window.api.onStreamState((st) => {
    if (st && st.reconnecting) {
      toast(`🔄 انقطع البث — جارٍ إعادة الاتصال تلقائياً (محاولة ${st.attempt}/3)…`, 4500);
    } else if (st && st.failed) {
      toast('⚠️ تعذّرت إعادة الاتصال التلقائي، تحقق من الكابل أو الواي فاي', 5500);
    }
  });

  window.api.onEnded((d) => {
    if (d.recFile) {
      toast('✅ توقف البث وحُفظ التسجيل بنجاح في مجلد الفيديوهات/DZMirror', 5500);
      loadRecordings();
    } else if (d.code && d.msg) {
      toast('⚠️ توقف البث: ' + d.msg, 6500);
    } else if (d.code) {
      toast('⚠️ توقف البث (رمز ' + d.code + ')', 4500);
    }
  });
}

// ---------- System Health Tab ----------
async function runHealthCheck() {
  const h = await call('sys:health');
  if (!h || !h.ok) return;
  const rows = [
    ['محرك الاتصال بأندرويد (adb.exe)', h.adb, h.adb ? '✅ جاهز' : '❌ مفقود في مجلد bin'],
    ['محرك بث الشاشة (scrcpy.exe)', h.scrcpy, h.scrcpy ? '✅ جاهز' : '❌ مفقود في مجلد bin'],
    ['محرك التحكم 360° واللمس المتعدد (keymap_bridge.ps1)', h.keymapBridge, h.keymapBridge ? '✅ جاهز (120Hz Multi-Touch)' : '❌ مفقود في helpers'],
    ['مستقبِل AirPlay للآيفون (uxplay.exe)', h.uxplay, h.uxplay ? '✅ جاهز' : '⚠️ غير مضاف بعد في bin/uxplay'],
    ['تعريفات أجهزة Apple', h.appleDriver, h.appleDriver ? '✅ مثبتة' : '⚠️ غير مثبتة'],
    ['خدمة Bonjour لاكتشاف AirPlay', h.bonjourRunning, h.bonjourRunning ? '✅ تعمل' : (h.bonjourInstalled ? '⚠️ متوقفة' : '⚠️ غير مثبتة')],
    ['قواعد جدار الحماية لـ AirPlay', h.firewallRule, h.firewallRule ? '✅ مفتوحة' : '⚠️ غير مضافة']
  ];
  $('healthList').innerHTML = rows
    .map(([label, ok, txt]) => `<div class="check-item"><span>${label}</span><span class="${ok ? 'st-ok' : 'st-warn'}">${txt}</span></div>`)
    .join('');
}
$('bRunHealth').onclick = async () => { await runHealthCheck(); toast('✅ اكتمل فحص النظام'); };

// ---------- Race-Free Polling Loop ----------
async function tick() {
  if (!detectInFlight) {
    detectInFlight = true;
    try {
      render(await call('detect'));
    } catch {
      $('adbState').innerHTML = '<i class="dot"></i><span>خطأ في الاتصال</span>';
    } finally {
      detectInFlight = false;
    }
  }
  setTimeout(tick, 2400);
}

drawSettings();
renderSavedIps();
initKeymaps();
tick();
setInterval(pollTelemetry, 3500);
