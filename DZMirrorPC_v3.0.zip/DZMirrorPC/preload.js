const { contextBridge, ipcRenderer } = require('electron');

const ALLOWED = new Set([
  'detect',
  'adb:restart',
  'net:telemetry',
  'stream:start',
  'stream:stop',
  'stream:apply',
  'record:start',
  'record:stop',
  'recordings:list',
  'file:open',
  'file:reveal',
  'shot',
  'wifi:enable',
  'wifi:connect',
  'wifi:pair',
  'wifi:disconnect',
  'driver:fix',
  'oem:open',
  'apple:env',
  'apple:driver',
  'apple:bonjour',
  'apple:firewall',
  'apple:airplay:start',
  'apple:airplay:stop',
  'apple:airplay:status',
  'apple:airplay:pick',
  'keymap:load',
  'keymap:save',
  'keymap:reset',
  'keymap:export',
  'keymap:import',
  'keymap:mouselock',
  'keymap:overlay:open',
  'keymap:overlay:close',
  'keymap:overlay:mode',
  'keymap:overlay:config',
  'keymap:overlay:visibility',
  'folder:open',
  'sys:health',
  'sys:ips'
]);

function subscribe(channel, cb) {
  if (typeof cb !== 'function') return () => {};
  const listener = (_e, d) => cb(d);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
}

contextBridge.exposeInMainWorld('api', {
  call: (ch, ...args) =>
    ALLOWED.has(ch)
      ? ipcRenderer.invoke(ch, ...args)
      : Promise.resolve({ ok: false, msg: 'Channel not allowed' }),
  onEnded: (cb) => subscribe('stream:ended', cb),
  onStreamState: (cb) => subscribe('stream:state', cb),
  onAirplayState: (cb) => subscribe('airplay:state', cb),
  onKeymapEvent: (cb) => subscribe('keymap:event', cb),
  onOverlayData: (cb) => subscribe('overlay:data', cb)
});
