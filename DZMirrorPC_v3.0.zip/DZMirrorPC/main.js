'use strict';
const { app, BrowserWindow, ipcMain, shell, dialog, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn, spawnSync, execFile } = require('child_process');
const {
  DEFAULT_KEYMAPS,
  DEFAULT_MOUSE_CONFIG,
  migrateAndSanitizeKeymaps,
  resetProfileToDefault,
  sanitizeMouseConfig
} = require('./lib/keymap_engine');

const BIN = app.isPackaged ? path.join(process.resourcesPath, 'bin') : path.join(__dirname, 'bin');
const HELPERS = (() => {
  if (app.isPackaged) {
    const unpacked = path.join(process.resourcesPath, 'app.asar.unpacked', 'helpers');
    if (fs.existsSync(unpacked)) return unpacked;
  }
  return path.join(__dirname, 'helpers');
})();
const ADB = path.join(BIN, 'adb.exe');
const SCRCPY = path.join(BIN, 'scrcpy.exe');

// Active scrcpy sessions: serial -> { proc, opts, title, sdk, windowTitle, recording, recFile, recStart, recOpts, startedAt, userStopped, reconnectAttempts }
const sessions = new Map();
const restarting = new Set();
const reconnectTimers = new Map();

// AirPlay process state
let airplay = {
  proc: null,
  running: false,
  connected: false,
  name: 'DZ Mirror',
  resolution: '1920x1080',
  fps: 60,
  audio: true,
  customPath: '',
  logs: []
};

// Keymap overlay & bridge state
let overlayWin = null;
let bridgeProc = null;
let overlayTargetSerial = null;
let bridgeTouchMode = 'UNKNOWN';
let mouseLockedState = false;
let freeLookState = false;

let overlayConfig = {
  enabled: true,
  editMode: false,
  visible: true,
  opacity: 0.72,
  activeProfileId: 'pubg',
  mouse: Object.assign({}, DEFAULT_MOUSE_CONFIG),
  buttons: []
};

let win = null;

const VENDORS = {
  '04E8': 'Samsung', '2717': 'Xiaomi', '18D1': 'Google', '12D1': 'Huawei', '22D9': 'OPPO', '2A70': 'OnePlus',
  '0BB4': 'HTC', '22B8': 'Motorola', '1004': 'LG', '0FCE': 'Sony', '2D95': 'vivo', '2A45': 'Meizu',
  '0E8D': 'MediaTek (Infinix/Tecno/realme)', '1782': 'Unisoc', '05C6': 'Qualcomm', '19D2': 'ZTE',
  '0B05': 'ASUS', '17EF': 'Lenovo', '1949': 'Amazon', '1BBB': 'Alcatel/TCL', '05AC': 'Apple'
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const stamp = () => new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);

function sendMain(ch, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(ch, payload);
}
function sendOverlay(ch, payload) {
  if (overlayWin && !overlayWin.isDestroyed()) overlayWin.webContents.send(ch, payload);
}

function run(cmd, args, timeout = 15000) {
  return new Promise((res) => {
    execFile(
      cmd,
      args,
      { windowsHide: true, timeout, maxBuffer: 20 * 1024 * 1024, env: { ...process.env, ADB } },
      (err, so, se) => res({ ok: !err, code: err ? err.code : 0, out: String(so || '').trim(), err: String(se || '').trim() })
    );
  });
}

const adb = (args, t) => run(ADB, args, t);
const ps = (script, t) =>
  run('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], t || 20000);

function getLocalIPs() {
  const nets = os.networkInterfaces();
  const ips = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) {
        ips.push({ iface: name, address: net.address });
      }
    }
  }
  return ips;
}

// ---------- Connection Latency & System Telemetry ----------
async function measureDeviceLatency(serial) {
  if (!fs.existsSync(ADB) || !serial) return null;
  const t0 = process.hrtime.bigint();
  const r = await adb(['-s', serial, 'shell', 'echo', '1'], 3500);
  if (!r.ok) return null;
  const ms = Number(process.hrtime.bigint() - t0) / 1e6;
  return Math.max(1, Math.round(ms));
}

// ---------- Android Device Discovery ----------
async function deviceInfo(serial) {
  const cmd =
    'getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.product.marketname; ' +
    'getprop ro.build.version.release; getprop ro.build.version.sdk; dumpsys battery | grep level; wm size';
  const r = await adb(['-s', serial, 'shell', cmd], 8000);
  const L = r.out.split(/\r?\n/).map((s) => s.trim());
  const brandRaw = L[0] || 'Android';
  const brand = brandRaw.charAt(0).toUpperCase() + brandRaw.slice(1);
  const model = L[2] || L[1] || serial;
  const name = model.toLowerCase().startsWith(brand.toLowerCase()) ? model : `${brand} ${model}`;
  return {
    name,
    model: L[1] || '',
    brand,
    android: L[3] || '?',
    sdk: parseInt(L[4], 10) || 0,
    battery: (/level:\s*(\d+)/.exec(r.out) || [])[1] || null,
    size: (/size:\s*(\d+x\d+)/.exec(r.out) || [])[1] || null
  };
}

async function listDevices() {
  if (!fs.existsSync(ADB)) return [];
  const r = await adb(['devices', '-l']);
  const lines = r.out.split(/\r?\n/).slice(1).filter((l) => l.trim() && !l.startsWith('*'));
  const devs = await Promise.all(
    lines.map(async (l) => {
      const p = l.trim().split(/\s+/);
      const d = { serial: p[0], state: p[1], wifi: p[0].includes(':') || p[0].startsWith('adb-'), info: null };
      if (d.state === 'device') d.info = await deviceInfo(d.serial);
      return d;
    })
  );
  return devs;
}

// ---------- USB + Apple Environment Detection ----------
let usbCache = { t: 0, data: [] };
async function scanUsb() {
  if (Date.now() - usbCache.t < 5000) return usbCache.data;
  const script =
    "Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -match 'VID_([0-9A-F]{4})' -or $_.FriendlyName -match 'iPhone|iPad|Apple Mobile Device' } | " +
    'Select-Object FriendlyName,Class,Status,InstanceId | ConvertTo-Json -Compress';
  const r = await ps(script, 15000);
  let arr = [];
  try {
    const j = JSON.parse(r.out);
    arr = Array.isArray(j) ? j : j ? [j] : [];
  } catch (e) {
    arr = [];
  }
  const vidOf = (d) => ((/VID_([0-9A-F]{4})/i.exec(d.InstanceId || '') || [])[1] || '').toUpperCase();
  const out = [];
  const seen = new Set();

  for (const d of arr) {
    const inst = d.InstanceId || '';
    const fname = d.FriendlyName || '';
    const vid = vidOf(d);
    const isApple = vid === '05AC' || /iphone|ipad|apple mobile device/i.test(fname);

    if (!isApple && /&MI_/i.test(inst)) continue;
    const nameHit = /android|phone|adb|mtp|iphone|ipad|apple mobile/i.test(fname);
    if (!VENDORS[vid] && !isApple && !nameHit) continue;
    if (/hub|host controller|root hub|camera|audio endpoint/i.test(fname)) continue;

    const dedupKey = isApple ? `APPLE_${(inst.split('\\')[2] || fname).split('&')[0]}` : inst;
    if (seen.has(dedupKey)) continue;
    seen.add(dedupKey);

    const sameVidItems = arr.filter((x) =>
      isApple ? vidOf(x) === '05AC' || /iphone|ipad|apple mobile/i.test(x.FriendlyName || '') : vidOf(x) === vid
    );
    const hasOk = sameVidItems.some((x) => x.Status === 'OK');
    const hasIssue = !hasOk && sameVidItems.some((x) => x.Status && x.Status !== 'OK');

    out.push({
      vid: vid || (isApple ? '05AC' : ''),
      kind: isApple ? 'ios' : 'android',
      vendor: isApple ? 'Apple' : VENDORS[vid] || 'Android',
      name: fname || (isApple ? 'Apple iPhone' : 'Android Device'),
      status: hasOk ? 'OK' : d.Status || 'Unknown',
      issue: hasIssue
    });
  }
  usbCache = { t: Date.now(), data: out };
  return out;
}

let appleEnvCache = { t: 0, data: null };
async function checkAppleEnv(force = false) {
  if (!force && appleEnvCache.data && Date.now() - appleEnvCache.t < 10000) return appleEnvCache.data;
  const script = `
    $res = @{
      usbaaplSys = (Test-Path "$env:SystemRoot\\System32\\drivers\\usbaapl64.sys") -or (Test-Path "$env:SystemRoot\\System32\\drivers\\usbaapl.sys");
      amdsService = $false;
      amdsRunning = $false;
      appleStoreApp = $false;
      bonjourInstalled = $false;
      bonjourRunning = $false;
      pnpAppleOk = $false;
      firewallRule = $false;
    }
    $s1 = Get-Service -Name 'Apple Mobile Device Service','AppleMobileDeviceService' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($s1) { $res.amdsService = $true; $res.amdsRunning = ($s1.Status -eq 'Running') }
    $appx = Get-AppxPackage -Name '*AppleDevices*','*iTunes*' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($appx) { $res.appleStoreApp = $true }
    $bj = Get-Service -Name 'Bonjour Service' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($bj) { $res.bonjourInstalled = $true; $res.bonjourRunning = ($bj.Status -eq 'Running') }
    $pnp = Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object { ($_.InstanceId -match 'VID_05AC' -or $_.FriendlyName -match 'Apple Mobile Device|Apple iPhone') -and $_.Status -eq 'OK' } | Select-Object -First 1
    if ($pnp) { $res.pnpAppleOk = $true }
    $fw = Get-NetFirewallRule -DisplayName 'DZMirror AirPlay*' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($fw) { $res.firewallRule = $true }
    $res | ConvertTo-Json -Compress
  `;
  const r = await ps(script, 15000);
  let info = {
    usbaaplSys: false,
    amdsService: false,
    amdsRunning: false,
    appleStoreApp: false,
    bonjourInstalled: false,
    bonjourRunning: false,
    pnpAppleOk: false,
    firewallRule: false
  };
  try {
    const parsed = JSON.parse(r.out);
    if (parsed) Object.assign(info, parsed);
  } catch (e) { /* ignore */ }

  const driverInstalled = Boolean(info.usbaaplSys || info.amdsService || info.appleStoreApp || info.pnpAppleOk);
  const uxPath = findUxplay();
  const data = {
    ...info,
    driverInstalled,
    uxplayFound: Boolean(uxPath),
    uxplayPath: uxPath || '',
    airplayRunning: airplay.running,
    airplayConnected: airplay.connected,
    ips: getLocalIPs()
  };
  appleEnvCache = { t: Date.now(), data };
  return data;
}

function findUxplay() {
  const candidates = [
    airplay.customPath,
    path.join(BIN, 'uxplay', 'uxplay.exe'),
    path.join(BIN, 'uxplay.exe'),
    path.join(process.env.ProgramFiles || 'C:\\Program Files', 'UxPlay', 'uxplay.exe'),
    path.join(process.env.LOCALAPPDATA || '', 'DZMirror', 'uxplay', 'uxplay.exe')
  ].filter(Boolean);
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

function findInf(dir, names = ['android_winusb.inf']) {
  try {
    for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, f.name);
      if (f.isDirectory()) {
        const r = findInf(p, names);
        if (r) return r;
      } else if (names.includes(f.name.toLowerCase())) {
        return p;
      }
    }
  } catch (e) { /* ignore */ }
  return null;
}

function getActiveSummary() {
  const out = {};
  for (const [serial, s] of sessions.entries()) {
    out[serial] = {
      recording: Boolean(s.recording),
      recStart: s.recStart || 0,
      recFile: s.recFile || '',
      startedAt: s.startedAt || 0,
      opts: s.opts || {},
      restarting: restarting.has(serial)
    };
  }
  return out;
}

async function detect() {
  const [devices, usb, appleEnv] = await Promise.all([listDevices(), scanUsb(), checkAppleEnv(false)]);
  return {
    ok: true,
    devices,
    usb,
    appleDriver: appleEnv.driverInstalled,
    appleEnv,
    active: [...sessions.keys()],
    sessions: getActiveSummary(),
    airplay: {
      running: airplay.running,
      connected: airplay.connected,
      name: airplay.name,
      uxplayFound: appleEnv.uxplayFound
    },
    overlayActive: Boolean(overlayWin && !overlayWin.isDestroyed()),
    overlaySerial: overlayTargetSerial,
    mouseLocked: mouseLockedState,
    freeLook: freeLookState,
    touchMode: bridgeTouchMode
  };
}

// ---------- Graceful Scrcpy Stream Engine + Hot-Swap Quality + Auto-Reconnect ----------
function buildScrcpyArgs(serial, o, recFile) {
  const winTitle = `DZ Mirror - ${o.title || serial}`;
  const fps = Number(o.fps) || 60;
  const bitrate = Number(o.bitrate) || 24;
  const codec = o.codec || 'h264';
  const a = [
    '-s', serial,
    `--window-title=${winTitle}`,
    `--max-fps=${fps}`,
    `--video-bit-rate=${bitrate}M`,
    `--video-codec=${codec}`,
    o.mode === 'fast' ? '--video-buffer=0' : '--video-buffer=50'
  ];

  const renderDriver = o.renderDriver || 'direct3d';
  if (renderDriver && renderDriver !== 'auto') {
    a.push(`--render-driver=${renderDriver}`);
  }

  const maxSize = Number(o.maxSize) || 0;
  if (maxSize > 0) a.push(`--max-size=${maxSize}`);

  if (o.audio && (Number(o.sdk) || 0) >= 30) {
    a.push(o.mode === 'fast' ? '--audio-buffer=30' : '--audio-buffer=75');
  } else {
    a.push('--no-audio');
  }

  if (o.awake) a.push('--stay-awake');
  if (o.off) a.push('--turn-screen-off');
  if (o.touch) a.push('--show-touches');
  if (o.top) a.push('--always-on-top');
  if (o.borderless) a.push('--window-borderless');
  if (o.view) a.push('--no-control');

  if (recFile) {
    a.push(`--record=${recFile}`);
  }
  return { args: a, winTitle };
}

function clearReconnectTimer(serial) {
  if (reconnectTimers.has(serial)) {
    clearTimeout(reconnectTimers.get(serial));
    reconnectTimers.delete(serial);
  }
}

async function stopStreamGracefully(serial, markUserStopped = false) {
  clearReconnectTimer(serial);
  const sess = sessions.get(serial);
  if (!sess || !sess.proc) return;
  if (markUserStopped) sess.userStopped = true;
  const proc = sess.proc;
  const pid = proc.pid;

  const exited = new Promise((resolve) => {
    if (proc.exitCode !== null) return resolve();
    proc.once('exit', () => resolve());
  });

  if (pid && process.platform === 'win32') {
    ps(`$p = Get-Process -Id ${pid} -ErrorAction SilentlyContinue; if ($p) { $p.CloseMainWindow() | Out-Null }`, 3000).catch(() => {});
  } else {
    try { proc.kill('SIGINT'); } catch (e) { /* ignore */ }
  }

  await Promise.race([exited, sleep(sess.recording ? 2000 : 900)]);

  if (proc.exitCode === null) {
    if (pid && process.platform === 'win32') {
      await run('taskkill.exe', ['/PID', String(pid), '/T', '/F'], 4000);
    } else {
      try { proc.kill('SIGKILL'); } catch (e) { /* ignore */ }
    }
    await Promise.race([exited, sleep(500)]);
  }
  sessions.delete(serial);
}

function scheduleAutoReconnect(serial, savedOpts, attempt = 1) {
  if (attempt > 3) {
    sendMain('stream:state', { serial, active: false, reconnecting: false, failed: true });
    return;
  }
  const delayMs = attempt * 1800;
  sendMain('stream:state', { serial, active: false, reconnecting: true, attempt });
  const handle = setTimeout(async () => {
    reconnectTimers.delete(serial);
    if (sessions.has(serial)) return;
    if (serial.includes(':')) {
      await adb(['connect', serial], 8000);
    }
    const devs = await listDevices();
    const ready = devs.some((d) => d.serial === serial && d.state === 'device');
    if (ready) {
      const res = spawnStream(serial, savedOpts, null, null, attempt);
      if (res.ok && overlayTargetSerial === serial) {
        const s = sessions.get(serial);
        if (s) startKeymapBridge(s.windowTitle);
      }
    } else {
      scheduleAutoReconnect(serial, savedOpts, attempt + 1);
    }
  }, delayMs);
  reconnectTimers.set(serial, handle);
}

function spawnStream(serial, o, recFile = null, recOpts = null, reconnectAttempt = 0) {
  if (!fs.existsSync(SCRCPY)) return { ok: false, msg: 'محرك البث (scrcpy.exe) غير موجود في مجلد bin' };

  clearReconnectTimer(serial);
  const effectiveOpts = Object.assign({}, o);
  if (recFile && recOpts && recOpts.quality && recOpts.quality !== 'match') {
    if (recOpts.quality === '720p60') { effectiveOpts.maxSize = 1280; effectiveOpts.fps = 60; effectiveOpts.bitrate = 12; }
    else if (recOpts.quality === '1080p60') { effectiveOpts.maxSize = 1920; effectiveOpts.fps = 60; effectiveOpts.bitrate = 24; }
    else if (recOpts.quality === 'orig40') { effectiveOpts.maxSize = 0; effectiveOpts.fps = 60; effectiveOpts.bitrate = 40; }
  }

  const { args, winTitle } = buildScrcpyArgs(serial, effectiveOpts, recFile);
  const log = [];
  const c = spawn(SCRCPY, args, { windowsHide: true, env: { ...process.env, ADB } });

  const sess = {
    proc: c,
    opts: o,
    title: o.title || serial,
    sdk: o.sdk || 0,
    windowTitle: winTitle,
    recording: Boolean(recFile),
    recFile: recFile || '',
    recStart: recFile ? Date.now() : 0,
    recOpts: recOpts || null,
    startedAt: Date.now(),
    userStopped: false,
    reconnectAttempt
  };
  sessions.set(serial, sess);

  const grab = (b) => {
    log.push(...String(b).split(/\r?\n/).filter(Boolean));
    if (log.length > 40) log.splice(0, log.length - 40);
  };
  c.stdout.on('data', grab);
  c.stderr.on('data', grab);

  c.on('error', (err) => {
    if (sessions.get(serial)?.proc === c) sessions.delete(serial);
    if (!restarting.has(serial)) {
      sendMain('stream:ended', { serial, code: -1, msg: String(err) });
    }
  });

  c.on('exit', (code) => {
    const isCurrent = sessions.get(serial)?.proc === c;
    if (isCurrent) sessions.delete(serial);
    if (restarting.has(serial)) return;

    const shouldReconnect = Boolean(
      o.autoReconnect !== false &&
      !sess.userStopped &&
      code !== 0 &&
      !sess.recording &&
      (Date.now() - sess.startedAt > 2500)
    );

    if (shouldReconnect) {
      scheduleAutoReconnect(serial, o, (sess.reconnectAttempt || 0) + 1);
      return;
    }

    if (overlayTargetSerial === serial) closeKeymapOverlay();

    const bad = log.filter((l) => /ERROR/i.test(l)).slice(-2).join(' | ');
    sendMain('stream:ended', {
      serial,
      code,
      msg: code ? bad : '',
      recFile: sess.recFile || ''
    });
  });

  sendMain('stream:state', { serial, active: true, recording: sess.recording, recStart: sess.recStart, reconnecting: false });
  return { ok: true, recFile: sess.recFile };
}

// ---------- Keymap Storage, Atomic Config & Overlay Window ----------
function keymapFile() {
  return path.join(app.getPath('userData'), 'keymaps_v3.json');
}
function legacyKeymapFile() {
  return path.join(app.getPath('userData'), 'keymaps.json');
}
function bridgeConfigFile() {
  return path.join(app.getPath('userData'), 'keymap_runtime.json');
}

function atomicWriteJson(filePath, dataObj) {
  const tmp = `${filePath}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(dataObj, null, 2), 'utf8');
  fs.renameSync(tmp, filePath);
}

function loadKeymaps() {
  try {
    const p3 = keymapFile();
    if (fs.existsSync(p3)) {
      return migrateAndSanitizeKeymaps(JSON.parse(fs.readFileSync(p3, 'utf8')));
    }
    const p2 = legacyKeymapFile();
    if (fs.existsSync(p2)) {
      const migrated = migrateAndSanitizeKeymaps(JSON.parse(fs.readFileSync(p2, 'utf8')));
      saveKeymaps(migrated);
      return migrated;
    }
  } catch (e) { /* ignore */ }
  return migrateAndSanitizeKeymaps(DEFAULT_KEYMAPS);
}

function saveKeymaps(data) {
  try {
    const clean = migrateAndSanitizeKeymaps(data);
    atomicWriteJson(keymapFile(), clean);
    return { ok: true, data: clean };
  } catch (e) {
    return { ok: false, msg: String(e) };
  }
}

function writeBridgeConfig() {
  try {
    atomicWriteJson(bridgeConfigFile(), {
      enabled: overlayConfig.enabled,
      editMode: overlayConfig.editMode,
      mouse: sanitizeMouseConfig(overlayConfig.mouse),
      buttons: overlayConfig.buttons || []
    });
    if (bridgeProc && bridgeProc.stdin && !bridgeProc.stdin.destroyed) {
      bridgeProc.stdin.write('RELOAD\n');
    }
  } catch (e) { /* ignore */ }
}

function stopKeymapBridge() {
  if (bridgeProc) {
    try {
      if (bridgeProc.stdin && !bridgeProc.stdin.destroyed) bridgeProc.stdin.write('QUIT\n');
    } catch (e) { /* ignore */ }
    try { bridgeProc.kill(); } catch (e) { /* ignore */ }
    bridgeProc = null;
  }
  mouseLockedState = false;
  freeLookState = false;
}

function startKeymapBridge(windowTitle) {
  stopKeymapBridge();
  const scriptPath = path.join(HELPERS, 'keymap_bridge.ps1');
  if (!fs.existsSync(scriptPath)) {
    sendMain('keymap:event', { type: 'error', msg: 'لم يتم العثور على محرك التحكم helpers/keymap_bridge.ps1' });
    return;
  }
  writeBridgeConfig();

  bridgeProc = spawn(
    'powershell.exe',
    ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', scriptPath, '-WindowTitle', windowTitle, '-ConfigPath', bridgeConfigFile()],
    { windowsHide: true }
  );

  let buf = '';
  bridgeProc.stdout.on('data', (chunk) => {
    buf += String(chunk);
    const lines = buf.split(/\r?\n/);
    buf = lines.pop() || '';
    for (const raw of lines) {
      const line = raw.trim();
      if (!line) continue;
      if (line.startsWith('BOUNDS:')) {
        const parts = line.slice(7).split(',').map(Number);
        const [vis, x, y, w, h] = parts;
        if (overlayWin && !overlayWin.isDestroyed()) {
          if (vis === 1 && w > 20 && h > 20) {
            const sf = screen.getDisplayNearestPoint({ x, y }).scaleFactor || 1;
            overlayWin.setBounds({
              x: Math.round(x / sf),
              y: Math.round(y / sf),
              width: Math.round(w / sf),
              height: Math.round(h / sf)
            });
            if (!overlayWin.isVisible()) overlayWin.showInactive();
          } else if (!overlayConfig.editMode) {
            overlayWin.hide();
          }
        }
      } else if (line === 'TOGGLE_VIS') {
        overlayConfig.visible = !overlayConfig.visible;
        sendOverlay('overlay:data', overlayConfig);
        sendMain('keymap:event', { type: 'visibility', visible: overlayConfig.visible });
      } else if (line.startsWith('TOUCH_MODE:')) {
        bridgeTouchMode = line.slice(11).trim();
        sendMain('keymap:event', { type: 'touch_mode', mode: bridgeTouchMode });
      } else if (line.startsWith('MOUSELOCK:')) {
        mouseLockedState = line.slice(10).trim() === '1';
        sendOverlay('keymap:event', { type: 'mouselock', locked: mouseLockedState });
        sendMain('keymap:event', { type: 'mouselock', locked: mouseLockedState });
      } else if (line.startsWith('FREELOOK:')) {
        freeLookState = line.slice(9).trim() === '1';
        sendOverlay('keymap:event', { type: 'freelook', active: freeLookState });
        sendMain('keymap:event', { type: 'freelook', active: freeLookState });
      } else if (line.startsWith('JOY:')) {
        const [nx, ny, sp] = line.slice(4).split(',');
        sendOverlay('keymap:event', { type: 'joy', nx: Number(nx) || 0, ny: Number(ny) || 0, sprint: sp === '1' });
      } else if (line.startsWith('KEY:')) {
        const [, id, state] = line.split(':');
        sendOverlay('keymap:event', { type: 'press', id, active: state === '1' });
      }
    }
  });

  bridgeProc.on('exit', () => {
    bridgeProc = null;
    mouseLockedState = false;
    freeLookState = false;
  });
}

function closeKeymapOverlay() {
  stopKeymapBridge();
  overlayTargetSerial = null;
  if (overlayWin && !overlayWin.isDestroyed()) {
    overlayWin.close();
  }
  overlayWin = null;
  sendMain('keymap:event', { type: 'closed' });
}

function openKeymapOverlay(serial, cfg) {
  const sess = sessions.get(serial);
  if (!sess) return { ok: false, msg: 'ابدأ بث شاشة الهاتف أولاً لتفعيل طبقة أزرار التحكم' };

  overlayTargetSerial = serial;
  if (cfg) Object.assign(overlayConfig, cfg);

  if (overlayWin && !overlayWin.isDestroyed()) {
    sendOverlay('overlay:data', overlayConfig);
    writeBridgeConfig();
    return { ok: true };
  }

  overlayWin = new BrowserWindow({
    width: 420,
    height: 760,
    transparent: true,
    frame: false,
    resizable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    hasShadow: false,
    focusable: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  overlayWin.setAlwaysOnTop(true, 'screen-saver');
  overlayWin.setIgnoreMouseEvents(!overlayConfig.editMode, { forward: true });
  overlayWin.loadFile(path.join(__dirname, 'renderer', 'overlay.html'));
  overlayWin.webContents.once('did-finish-load', () => {
    sendOverlay('overlay:data', overlayConfig);
  });
  overlayWin.on('closed', () => {
    stopKeymapBridge();
    overlayWin = null;
    overlayTargetSerial = null;
    sendMain('keymap:event', { type: 'closed' });
  });

  startKeymapBridge(sess.windowTitle);
  return { ok: true };
}

// ---------- Main Window ----------
function createWindow() {
  const icon = path.join(__dirname, 'build', 'icon.png');
  win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 980,
    minHeight: 650,
    backgroundColor: '#050807',
    title: 'DZ Mirror Pro 3.0',
    icon: fs.existsSync(icon) ? icon : undefined,
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: '#070c0a', symbolColor: '#e2f5ec', height: 44 },
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.setMenuBarVisibility(false);
  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

if (!app.requestSingleInstanceLock()) app.quit();
app.on('second-instance', () => {
  if (win) {
    if (win.isMinimized()) win.restore();
    win.focus();
  }
});

app.whenReady().then(() => {
  if (fs.existsSync(ADB)) adb(['start-server'], 20000);
  createWindow();
});

app.on('window-all-closed', () => app.quit());
app.on('will-quit', () => {
  for (const serial of reconnectTimers.keys()) clearReconnectTimer(serial);
  closeKeymapOverlay();
  if (airplay.proc) {
    try { airplay.proc.kill(); } catch (e) { /* ignore */ }
  }
  for (const s of sessions.values()) {
    try { s.proc.kill(); } catch (e) { /* ignore */ }
  }
  try {
    if (fs.existsSync(ADB)) spawnSync(ADB, ['kill-server'], { windowsHide: true, timeout: 4000 });
  } catch (e) { /* ignore */ }
});

// ---------- IPC Handlers ----------
ipcMain.handle('detect', () => detect());
ipcMain.handle('sys:ips', () => ({ ok: true, ips: getLocalIPs() }));

ipcMain.handle('net:telemetry', async (_e, serial) => {
  const target = serial || [...sessions.keys()][0] || null;
  const latencyMs = target ? await measureDeviceLatency(target) : null;
  const mem = process.memoryUsage();
  return {
    ok: true,
    serial: target,
    latencyMs,
    rssMB: Math.round(mem.rss / (1024 * 1024)),
    activeStreams: sessions.size,
    touchMode: bridgeTouchMode,
    mouseLocked: mouseLockedState,
    freeLook: freeLookState
  };
});

ipcMain.handle('sys:health', async () => {
  const appleEnv = await checkAppleEnv(true);
  const helperScript = path.join(HELPERS, 'keymap_bridge.ps1');
  return {
    ok: true,
    adb: fs.existsSync(ADB),
    scrcpy: fs.existsSync(SCRCPY),
    keymapBridge: fs.existsSync(helperScript),
    uxplay: appleEnv.uxplayFound,
    uxplayPath: appleEnv.uxplayPath,
    appleDriver: appleEnv.driverInstalled,
    bonjourInstalled: appleEnv.bonjourInstalled,
    bonjourRunning: appleEnv.bonjourRunning,
    firewallRule: appleEnv.firewallRule,
    ips: appleEnv.ips
  };
});

ipcMain.handle('adb:restart', async () => {
  if (!fs.existsSync(ADB)) return { ok: false, msg: 'ملف adb.exe غير موجود في مجلد bin' };
  await adb(['kill-server']);
  await adb(['start-server'], 20000);
  usbCache.t = 0;
  return { ok: true };
});

// Stream Start / Stop / Seamless Hot-Swap Apply
ipcMain.handle('stream:start', (_e, serial, o) => {
  if (sessions.has(serial)) return { ok: false, msg: 'البث يعمل بالفعل لهذا الجهاز' };
  let recFile = null;
  if (o.rec) {
    const dir = path.join(app.getPath('videos'), 'DZMirror');
    fs.mkdirSync(dir, { recursive: true });
    const ext = o.recFormat === 'mp4' ? 'mp4' : 'mkv';
    recFile = path.join(dir, `${(o.title || 'phone').replace(/[^\w.-]+/g, '_')}-${stamp()}.${ext}`);
  }
  return spawnStream(serial, o, recFile, o.rec ? { quality: o.recQuality || 'match', format: o.recFormat || 'mkv' } : null);
});

ipcMain.handle('stream:stop', async (_e, serial) => {
  if (overlayTargetSerial === serial) closeKeymapOverlay();
  await stopStreamGracefully(serial, true);
  sendMain('stream:state', { serial, active: false, recording: false, reconnecting: false });
  return { ok: true };
});

ipcMain.handle('stream:apply', async (_e, serial, newOpts) => {
  const existing = sessions.get(serial);
  if (!existing) return { ok: false, msg: 'لا يوجد بث نشط لتحديثه' };
  if (restarting.has(serial)) return { ok: false, msg: 'جارٍ تطبيق التغييرات بالفعل…' };

  restarting.add(serial);
  const wasOverlayOpen = overlayTargetSerial === serial;
  const mergedOpts = Object.assign({}, existing.opts, newOpts, { title: existing.title, sdk: existing.sdk });

  try {
    await stopStreamGracefully(serial, true);
    await sleep(220);
    const res = spawnStream(serial, mergedOpts, null, null);
    if (res.ok && wasOverlayOpen) {
      const s = sessions.get(serial);
      if (s) startKeymapBridge(s.windowTitle);
    }
    return res;
  } finally {
    setTimeout(() => restarting.delete(serial), 350);
  }
});

// Dedicated On-Demand Screen Recording
ipcMain.handle('record:start', async (_e, serial, recOpts = {}) => {
  const existing = sessions.get(serial);
  if (!existing) return { ok: false, msg: 'ابدأ بث شاشة الهاتف أولاً ثم اضغط تسجيل' };
  if (existing.recording) return { ok: false, msg: 'التسجيل يعمل بالفعل' };
  if (restarting.has(serial)) return { ok: false, msg: 'انتظر لحظة حتى يكتمل تحديث البث' };

  const dir = path.join(app.getPath('videos'), 'DZMirror');
  fs.mkdirSync(dir, { recursive: true });
  const ext = recOpts.format === 'mp4' ? 'mp4' : 'mkv';
  const recFile = path.join(dir, `${(existing.title || 'phone').replace(/[^\w.-]+/g, '_')}-${stamp()}.${ext}`);

  restarting.add(serial);
  const wasOverlayOpen = overlayTargetSerial === serial;
  const baseOpts = Object.assign({}, existing.opts, {
    title: existing.title,
    sdk: existing.sdk,
    audio: recOpts.audio !== undefined ? Boolean(recOpts.audio) : existing.opts.audio
  });

  try {
    await stopStreamGracefully(serial, true);
    await sleep(220);
    const res = spawnStream(serial, baseOpts, recFile, recOpts);
    if (res.ok && wasOverlayOpen) {
      const s = sessions.get(serial);
      if (s) startKeymapBridge(s.windowTitle);
    }
    return { ok: res.ok, file: recFile, msg: res.ok ? 'بدأ تسجيل الشاشة بسلاسة' : res.msg };
  } finally {
    setTimeout(() => restarting.delete(serial), 350);
  }
});

ipcMain.handle('record:stop', async (_e, serial) => {
  const existing = sessions.get(serial);
  if (!existing || !existing.recording) return { ok: false, msg: 'لا يوجد تسجيل نشط حالياً' };

  const savedFile = existing.recFile;
  restarting.add(serial);
  const wasOverlayOpen = overlayTargetSerial === serial;
  const baseOpts = Object.assign({}, existing.opts, { title: existing.title, sdk: existing.sdk, rec: false });

  try {
    await stopStreamGracefully(serial, true);
    await sleep(250);
    const res = spawnStream(serial, baseOpts, null, null);
    if (res.ok && wasOverlayOpen) {
      const s = sessions.get(serial);
      if (s) startKeymapBridge(s.windowTitle);
    }
    return { ok: true, file: savedFile, msg: 'تم حفظ التسجيل بنجاح ومواصلة البث' };
  } finally {
    setTimeout(() => restarting.delete(serial), 350);
  }
});

ipcMain.handle('recordings:list', () => {
  const dir = path.join(app.getPath('videos'), 'DZMirror');
  fs.mkdirSync(dir, { recursive: true });
  try {
    const files = fs
      .readdirSync(dir)
      .filter((f) => /\.(mp4|mkv|webm)$/i.test(f))
      .map((name) => {
        const full = path.join(dir, name);
        const st = fs.statSync(full);
        return { name, path: full, size: st.size, mtime: st.mtimeMs };
      })
      .sort((a, b) => b.mtime - a.mtime)
      .slice(0, 20);
    return { ok: true, dir, files };
  } catch (e) {
    return { ok: true, dir, files: [] };
  }
});

ipcMain.handle('file:open', (_e, filePath) => {
  if (filePath && fs.existsSync(filePath)) {
    shell.openPath(filePath);
    return { ok: true };
  }
  return { ok: false };
});
ipcMain.handle('file:reveal', (_e, filePath) => {
  if (filePath && fs.existsSync(filePath)) {
    shell.showItemInFolder(filePath);
    return { ok: true };
  }
  return { ok: false };
});

// Screenshot
ipcMain.handle('shot', (_e, serial, name) =>
  new Promise((res) => {
    const dir = path.join(app.getPath('pictures'), 'DZMirror');
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `${(name || 'phone').replace(/[^\w.-]+/g, '_')}-${stamp()}.png`);
    const p = spawn(ADB, ['-s', serial, 'exec-out', 'screencap', '-p'], { windowsHide: true });
    const ws = fs.createWriteStream(file);
    p.stdout.pipe(ws);
    ws.on('finish', () => {
      try {
        res({ ok: fs.statSync(file).size > 1000, file });
      } catch (e) {
        res({ ok: false });
      }
    });
    p.on('error', () => res({ ok: false }));
  })
);

// Wi-Fi ADB
ipcMain.handle('wifi:enable', async (_e, serial) => {
  const r = await adb(['-s', serial, 'shell', 'ip', '-f', 'inet', 'addr', 'show', 'wlan0']);
  const m = /inet (\d+\.\d+\.\d+\.\d+)/.exec(r.out);
  if (!m) return { ok: false, msg: 'تعذّر معرفة عنوان الواي فاي، تأكد أن الهاتف متصل بنفس شبكة الواي فاي' };
  await adb(['-s', serial, 'tcpip', '5555']);
  await sleep(1600);
  const c = await adb(['connect', `${m[1]}:5555`]);
  return { ok: /connected/i.test(c.out), msg: c.out || c.err, ip: m[1] };
});

ipcMain.handle('wifi:connect', async (_e, host) => {
  const h = String(host || '').trim();
  if (!/^[\w.\-]+(:\d+)?$/.test(h)) return { ok: false, msg: 'عنوان IP غير صحيح' };
  const c = await adb(['connect', h.includes(':') ? h : `${h}:5555`], 20000);
  return { ok: /connected/i.test(c.out) && !/cannot|failed/i.test(c.out), msg: c.out || c.err };
});

ipcMain.handle('wifi:pair', async (_e, host, code) => {
  if (!/^[\w.\-]+:\d+$/.test(String(host || '').trim()) || !/^\d{6}$/.test(String(code || '').trim())) {
    return { ok: false, msg: 'أدخل العنوان مع المنفذ (مثل 192.168.1.5:37123) والرمز المكوّن من 6 أرقام' };
  }
  const r = await adb(['pair', host.trim(), code.trim()], 25000);
  return { ok: /success/i.test(r.out), msg: r.out || r.err };
});

ipcMain.handle('wifi:disconnect', async (_e, serial) => {
  clearReconnectTimer(serial);
  await adb(['disconnect', serial]);
  return { ok: true };
});

// Drivers (Android & Apple)
ipcMain.handle('driver:fix', async (_e, kind = 'android') => {
  const names = kind === 'ios' ? ['usbaapl64.inf', 'usbaapl.inf', 'netaapl64.inf'] : ['android_winusb.inf'];
  const inf = findInf(path.join(BIN, 'driver'), names);
  if (!inf) {
    if (kind === 'ios') {
      shell.openExternal('ms-windows-store://pdp/?productid=9NP83LWLZM3F');
      return { ok: true, msg: 'تم فتح تطبيق Apple Devices الرسمي لتثبيت/تحديث تعريفات الآيفون' };
    }
    return { ok: false, msg: 'حزمة التعريفات المحلية غير مضمّنة، استخدم زر موقع الشركة المصنّعة' };
  }
  const safe = inf.replace(/'/g, "''");
  const r = await ps(`Start-Process -FilePath pnputil.exe -ArgumentList '/add-driver "${safe}" /install' -Verb RunAs -Wait`, 120000);
  await run('pnputil.exe', ['/scan-devices']);
  if (kind !== 'ios' && fs.existsSync(ADB)) {
    await adb(['kill-server']);
    await adb(['start-server'], 20000);
  }
  usbCache.t = 0;
  appleEnvCache.t = 0;
  return { ok: r.ok, msg: r.ok ? 'تم تثبيت التعريفات بنجاح. افصل الهاتف وأعد توصيله' : 'أُلغي التثبيت أو لم تُمنح صلاحية المسؤول' };
});

ipcMain.handle('oem:open', (_e, vendor) => {
  const q = encodeURIComponent(`${String(vendor).split(' ')[0]} USB driver Windows`);
  shell.openExternal(`https://www.google.com/search?q=${q}`);
  return { ok: true };
});

// Apple / iPhone & AirPlay Management
ipcMain.handle('apple:env', () => checkAppleEnv(true));
ipcMain.handle('apple:driver', () => {
  shell.openExternal('ms-windows-store://pdp/?productid=9NP83LWLZM3F');
  return { ok: true, msg: 'تم فتح Apple Devices على متجر مايكروسوفت' };
});
ipcMain.handle('apple:bonjour', () => {
  shell.openExternal('https://support.apple.com/en-us/106380');
  return { ok: true, msg: 'تم فتح صفحة تحميل Bonjour Print Services الرسمي من Apple' };
});

ipcMain.handle('apple:firewall', async () => {
  const ux = findUxplay();
  const cmds = [
    `New-NetFirewallRule -DisplayName 'DZMirror AirPlay TCP' -Direction Inbound -Protocol TCP -LocalPort 7000,7001,7100,47000 -Action Allow -ErrorAction SilentlyContinue`,
    `New-NetFirewallRule -DisplayName 'DZMirror AirPlay UDP' -Direction Inbound -Protocol UDP -LocalPort 5353,6000-6005,7010-7011 -Action Allow -ErrorAction SilentlyContinue`
  ];
  if (ux) {
    const safeUx = ux.replace(/'/g, "''");
    cmds.push(`New-NetFirewallRule -DisplayName 'DZMirror AirPlay UxPlay' -Direction Inbound -Program '${safeUx}' -Action Allow -ErrorAction SilentlyContinue`);
  }
  const joined = cmds.join('; ');
  const r = await ps(`Start-Process powershell -Verb RunAs -Wait -ArgumentList '-NoProfile -ExecutionPolicy Bypass -Command "${joined}"'`, 60000);
  appleEnvCache.t = 0;
  return {
    ok: r.ok,
    msg: r.ok ? 'تم فتح منافذ AirPlay و mDNS في جدار حماية ويندوز بنجاح' : 'لم يتم منح صلاحية المسؤول لتعديل جدار الحماية'
  };
});

ipcMain.handle('apple:airplay:pick', async () => {
  const res = await dialog.showOpenDialog(win, {
    title: 'اختر ملف uxplay.exe',
    filters: [{ name: 'Executable', extensions: ['exe'] }],
    properties: ['openFile']
  });
  if (res.canceled || !res.filePaths.length) return { ok: false };
  airplay.customPath = res.filePaths[0];
  appleEnvCache.t = 0;
  return { ok: true, path: airplay.customPath };
});

ipcMain.handle('apple:airplay:start', async (_e, cfg = {}) => {
  if (airplay.running && airplay.proc) {
    return { ok: true, msg: `مستقبِل AirPlay يعمل بالفعل باسم "${airplay.name}"` };
  }
  const ux = findUxplay();
  if (!ux) {
    return {
      ok: false,
      code: 'NO_UXPLAY',
      msg: 'ملف مستقبِل AirPlay (uxplay.exe) غير موجود في مجلد bin/uxplay. يمكنك تحديد مساره يدوياً.'
    };
  }

  const env = await checkAppleEnv(true);
  if (!env.bonjourRunning && env.bonjourInstalled) {
    await ps("Start-Service -Name 'Bonjour Service' -ErrorAction SilentlyContinue", 6000);
  }

  airplay.name = (cfg.name || 'DZ Mirror').trim() || 'DZ Mirror';
  airplay.resolution = cfg.resolution || '1920x1080';
  airplay.fps = Number(cfg.fps) || 60;
  airplay.audio = cfg.audio !== false;
  airplay.logs = [];
  airplay.connected = false;

  const args = ['-n', airplay.name, '-s', `${airplay.resolution}@${airplay.fps}`, '-fps', String(airplay.fps), '-nohold'];
  if (!airplay.audio) args.push('-a', 'off');

  try {
    const p = spawn(ux, args, { cwd: path.dirname(ux), windowsHide: true, env: { ...process.env } });
    airplay.proc = p;
    airplay.running = true;

    const pushLog = (chunk) => {
      const lines = String(chunk).split(/\r?\n/).filter(Boolean);
      for (const l of lines) {
        airplay.logs.push(l);
        if (airplay.logs.length > 40) airplay.logs.shift();
        if (/raop_rtp_mirror|connection established|begin video|Client connected/i.test(l)) airplay.connected = true;
        if (/Connection closed|reset|stopped/i.test(l)) airplay.connected = false;
      }
      sendMain('airplay:state', { running: airplay.running, connected: airplay.connected, name: airplay.name, logs: airplay.logs.slice(-8) });
    };

    p.stdout.on('data', pushLog);
    p.stderr.on('data', pushLog);
    p.on('error', (err) => {
      airplay.running = false; airplay.connected = false; airplay.proc = null;
      sendMain('airplay:state', { running: false, connected: false, error: String(err), logs: airplay.logs.slice(-8) });
    });
    p.on('exit', (code) => {
      airplay.running = false; airplay.connected = false; airplay.proc = null;
      sendMain('airplay:state', { running: false, connected: false, code, logs: airplay.logs.slice(-8) });
    });

    sendMain('airplay:state', { running: true, connected: false, name: airplay.name, logs: airplay.logs });
    return {
      ok: true,
      bonjourWarning: !env.bonjourInstalled,
      msg: env.bonjourInstalled
        ? `تم تشغيل AirPlay باسم "${airplay.name}". على الآيفون: مركز التحكم ← انعكاس الشاشة ← ${airplay.name}`
        : `تم تشغيل AirPlay، لكن خدمة Bonjour غير مثبتة — ثبّتها ليظهر "${airplay.name}" على الآيفون`
    };
  } catch (e) {
    airplay.running = false;
    return { ok: false, msg: 'تعذّر تشغيل مستقبِل AirPlay: ' + String(e) };
  }
});

ipcMain.handle('apple:airplay:stop', () => {
  if (airplay.proc) {
    try { airplay.proc.kill(); } catch (e) { /* ignore */ }
    airplay.proc = null;
  }
  airplay.running = false;
  airplay.connected = false;
  sendMain('airplay:state', { running: false, connected: false, name: airplay.name, logs: airplay.logs.slice(-8) });
  return { ok: true };
});

ipcMain.handle('apple:airplay:status', () => ({
  ok: true,
  running: airplay.running,
  connected: airplay.connected,
  name: airplay.name,
  logs: airplay.logs.slice(-12)
}));

// ---------- Keymap IPC (v3 Pro: Save, Reset, Import/Export, Live Mouse Lock) ----------
function applyKeymapDataToOverlay(clean) {
  const prof = (clean.profiles || []).find((p) => p.id === clean.activeProfileId) || (clean.profiles || [])[0];
  overlayConfig.activeProfileId = clean.activeProfileId;
  overlayConfig.opacity = clean.opacity ?? overlayConfig.opacity;
  overlayConfig.visible = clean.visible ?? overlayConfig.visible;
  overlayConfig.enabled = clean.enabled ?? overlayConfig.enabled;
  overlayConfig.mouse = sanitizeMouseConfig((prof && prof.mouse) || clean.mouse);
  overlayConfig.buttons = prof ? prof.buttons : [];
  writeBridgeConfig();
  sendOverlay('overlay:data', overlayConfig);
}

ipcMain.handle('keymap:load', () => ({ ok: true, data: loadKeymaps() }));

ipcMain.handle('keymap:save', (_e, data) => {
  const res = saveKeymaps(data);
  if (res.ok && res.data) applyKeymapDataToOverlay(res.data);
  return res;
});

ipcMain.handle('keymap:reset', (_e, profileId) => {
  const cur = loadKeymaps();
  const next = resetProfileToDefault(cur, profileId);
  const res = saveKeymaps(next);
  if (res.ok && res.data) applyKeymapDataToOverlay(res.data);
  return res;
});

ipcMain.handle('keymap:export', async (_e, data) => {
  const res = await dialog.showSaveDialog(win, {
    title: 'تصدير ملف إعدادات التحكم (Keymap JSON)',
    defaultPath: `DZMirror-Keymap-${stamp()}.json`,
    filters: [{ name: 'DZ Mirror Keymap JSON', extensions: ['json'] }]
  });
  if (res.canceled || !res.filePath) return { ok: false, canceled: true };
  try {
    const clean = migrateAndSanitizeKeymaps(data || loadKeymaps());
    fs.writeFileSync(res.filePath, JSON.stringify(clean, null, 2), 'utf8');
    return { ok: true, path: res.filePath };
  } catch (e) {
    return { ok: false, msg: String(e) };
  }
});

ipcMain.handle('keymap:import', async () => {
  const res = await dialog.showOpenDialog(win, {
    title: 'استيراد ملف إعدادات التحكم (Keymap JSON)',
    filters: [{ name: 'DZ Mirror Keymap JSON', extensions: ['json'] }],
    properties: ['openFile']
  });
  if (res.canceled || !res.filePaths.length) return { ok: false, canceled: true };
  try {
    const raw = JSON.parse(fs.readFileSync(res.filePaths[0], 'utf8'));
    const clean = migrateAndSanitizeKeymaps(raw);
    const saved = saveKeymaps(clean);
    if (saved.ok && saved.data) applyKeymapDataToOverlay(saved.data);
    return saved;
  } catch (e) {
    return { ok: false, msg: 'ملف JSON غير صالح أو تالف' };
  }
});

ipcMain.handle('keymap:mouselock', (_e, lock) => {
  if (bridgeProc && bridgeProc.stdin && !bridgeProc.stdin.destroyed) {
    bridgeProc.stdin.write(lock ? 'LOCK\n' : 'UNLOCK\n');
    return { ok: true };
  }
  return { ok: false, msg: 'طبقة التحكم غير نشطة' };
});

ipcMain.handle('keymap:overlay:open', (_e, serial, cfg) => openKeymapOverlay(serial, cfg));
ipcMain.handle('keymap:overlay:close', () => { closeKeymapOverlay(); return { ok: true }; });

ipcMain.handle('keymap:overlay:mode', (_e, editMode) => {
  overlayConfig.editMode = Boolean(editMode);
  if (overlayWin && !overlayWin.isDestroyed()) {
    overlayWin.setIgnoreMouseEvents(!overlayConfig.editMode, { forward: true });
    overlayWin.setFocusable(overlayConfig.editMode);
    if (overlayConfig.editMode) overlayWin.focus();
  }
  writeBridgeConfig();
  sendOverlay('overlay:data', overlayConfig);
  sendMain('keymap:event', { type: 'mode', editMode: overlayConfig.editMode });
  return { ok: true };
});

ipcMain.handle('keymap:overlay:config', (_e, partial) => {
  Object.assign(overlayConfig, partial || {});
  writeBridgeConfig();
  sendOverlay('overlay:data', overlayConfig);
  return { ok: true };
});

ipcMain.handle('keymap:overlay:visibility', (_e, visible) => {
  overlayConfig.visible = Boolean(visible);
  sendOverlay('overlay:data', overlayConfig);
  return { ok: true };
});

// Folders
ipcMain.handle('folder:open', (_e, kind) => {
  const dir = path.join(app.getPath(kind === 'video' ? 'videos' : 'pictures'), 'DZMirror');
  fs.mkdirSync(dir, { recursive: true });
  shell.openPath(dir);
  return { ok: true };
});
