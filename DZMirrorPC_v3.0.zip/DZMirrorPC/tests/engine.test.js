'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const engine = require('../lib/keymap_engine');

let passed = 0;
function test(name, fn) {
  fn();
  passed++;
  console.log(`  [PASS] ${name}`);
}

console.log('=== DZ Mirror Pro 3.0 Automated Verification Suite ===');

// 1. Default Profiles & v2 -> v3 Migration
test('Default PUBG profile has WASD joystick, 360° Aim, FreeLook, Fire LMB, ADS RMB', () => {
  const pubg = engine.DEFAULT_KEYMAPS.profiles.find((p) => p.id === 'pubg');
  assert.ok(pubg, 'PUBG profile must exist');
  assert.ok(pubg.buttons.some((b) => b.type === 'joystick'), 'Joystick missing');
  assert.ok(pubg.buttons.some((b) => b.type === 'aim'), 'Aim 360 zone missing');
  assert.ok(pubg.buttons.some((b) => b.type === 'freelook'), 'FreeLook eye missing');
  assert.ok(pubg.buttons.some((b) => b.key === 'LMB' && b.action === 'fire'), 'Fire LMB missing');
  assert.ok(pubg.buttons.some((b) => b.key === 'RMB' && b.action === 'ads'), 'ADS RMB missing');
});

test('Migrates legacy v2 keymaps cleanly to v3 and injects missing 360° Aim zone', () => {
  const legacyV2 = {
    activeProfileId: 'pubg',
    opacity: 0.8,
    profiles: [
      {
        id: 'pubg',
        name: 'PUBG Old',
        buttons: [
          { id: 'joy1', type: 'joystick', x: 17, y: 74, radius: 11 },
          { id: 'fire', type: 'tap', key: 'F', x: 86, y: 72, size: 54 }
        ]
      }
    ]
  };
  const migrated = engine.migrateAndSanitizeKeymaps(legacyV2);
  assert.strictEqual(migrated.version, 3);
  const btns = migrated.profiles[0].buttons;
  assert.strictEqual(btns.find((b) => b.id === 'fire').type, 'click', 'Legacy tap should normalize to click');
  assert.ok(btns.some((b) => b.type === 'aim'), 'Aim zone must be auto-added during migration');
  assert.ok(migrated.mouse && migrated.mouse.lockKey === 'CTRL', 'Default mouse config must be populated');
});

test('Reset profile restores exact default layout for active profile', () => {
  const custom = engine.migrateAndSanitizeKeymaps(engine.DEFAULT_KEYMAPS);
  custom.profiles[0].buttons = [];
  const restored = engine.resetProfileToDefault(custom, 'pubg');
  assert.ok(restored.profiles[0].buttons.length >= 15, 'Restored PUBG profile should have full default buttons');
});

// 2. Virtual Joystick 360° Vector & Sprint Physics
test('Joystick 360° diagonal movement is normalized (length = 1.0)', () => {
  const v = engine.computeJoystickVector({ up: true, right: true }, { radius: 11, sprintRadius: 19, sensitivity: 1.0 });
  assert.strictEqual(v.active, true);
  assert.ok(Math.abs(Math.hypot(v.nx, v.ny) - 1.0) < 1e-6, 'Diagonal vector must be unit normalized');
  assert.ok(v.nx > 0 && v.ny < 0, 'Up-Right vector must point top-right');
  assert.strictEqual(v.sprinting, false);
});

test('Joystick triggers Sprint when holding Shift or autoSprint forward >= 350ms', () => {
  const vShift = engine.computeJoystickVector({ up: true, sprint: true }, { radius: 11, sprintRadius: 19 });
  assert.strictEqual(vShift.sprinting, true);
  assert.strictEqual(vShift.radius, 19);

  const vAuto = engine.computeJoystickVector({ up: true, holdMs: 400 }, { radius: 11, sprintRadius: 19, autoSprint: true });
  assert.strictEqual(vAuto.sprinting, true);
  assert.strictEqual(vAuto.radius, 19);

  const vStop = engine.computeJoystickVector({}, { radius: 11, sprintRadius: 19 });
  assert.strictEqual(vStop.active, false);
});

// 3. Relative Mouse 360° Sensitivity, Scope Scaling, Invert Y & EMA Smoothing
test('Mouse relative movement applies DPI, X/Y sensitivity, Scope ADS scaling, Invert Y, and Smoothing', () => {
  const cfg = { sensX: 2.0, sensY: 1.5, scopeSens: 0.5, dpiScale: 1.0, smoothing: 0.0, invertY: false };
  const hip = engine.applyMouseSensitivityAndSmoothing(10, 10, { vx: 0, vy: 0 }, cfg, false);
  assert.strictEqual(hip.vx, 20);
  assert.strictEqual(hip.vy, 15);

  const scoped = engine.applyMouseSensitivityAndSmoothing(10, 10, { vx: 0, vy: 0 }, cfg, true);
  assert.strictEqual(scoped.vx, 10, 'Scope sensitivity 0.5x must halve horizontal speed');
  assert.strictEqual(scoped.vy, 7.5, 'Scope sensitivity 0.5x must halve vertical speed');

  const inv = engine.applyMouseSensitivityAndSmoothing(10, 10, { vx: 0, vy: 0 }, { ...cfg, invertY: true }, false);
  assert.strictEqual(inv.vy, -15, 'Invert Y must negate vertical delta');

  const smoothed = engine.applyMouseSensitivityAndSmoothing(10, 0, { vx: 0, vy: 0 }, { ...cfg, smoothing: 0.5 }, false);
  assert.strictEqual(smoothed.vx, 10, 'EMA smoothing 0.5 should blend previous 0 and raw 20 -> 10');
});

// 4. Arabic / English Layout-Independent Key Normalization
test('normalizeKeyCode maps physical e.code independently of Arabic keyboard layout', () => {
  assert.strictEqual(engine.normalizeKeyCode('KeyW', 'ص'), 'W');
  assert.strictEqual(engine.normalizeKeyCode('KeyA', 'ش'), 'A');
  assert.strictEqual(engine.normalizeKeyCode('Digit4', '٤'), '4');
  assert.strictEqual(engine.normalizeKeyCode('Space', ' '), 'SPACE');
  assert.strictEqual(engine.normalizeKeyCode('ControlLeft', 'Control'), 'CTRL');
  assert.strictEqual(engine.normalizeKeyCode('Backquote', 'ذ'), '~');
});

// 5. Structural & Packaging Integrity Checks
test('package.json unpacks helpers/ outside asar for PowerShell bridge execution', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8'));
  assert.ok(Array.isArray(pkg.build.asarUnpack) && pkg.build.asarUnpack.includes('helpers/**/*'), 'helpers/**/* must be in asarUnpack');
});

test('keymap_bridge.ps1 includes InjectTouchInput, WH_MOUSE_LL, ClipCursor, and 120Hz loop', () => {
  const ps1 = fs.readFileSync(path.join(__dirname, '..', 'helpers', 'keymap_bridge.ps1'), 'utf8');
  assert.ok(ps1.includes('InitializeTouchInjection'), 'Must use Windows InitializeTouchInjection');
  assert.ok(ps1.includes('InjectTouchInput'), 'Must use Windows InjectTouchInput');
  assert.ok(ps1.includes('WH_MOUSE_LL'), 'Must install WH_MOUSE_LL for relative mouse capture');
  assert.ok(ps1.includes('ClipCursor'), 'Must use ClipCursor for mouse lock');
  assert.ok(ps1.includes('PendingRecenterDown'), 'Must support seamless 360° edge recenter');
  assert.ok(!ps1.includes('Thread.Sleep(8);\n        }\n        SendMouse'), 'Must not block HookCallback with Sleep');
});

console.log(`\nALL ${passed} TESTS PASSED SUCCESSFULLY!`);
