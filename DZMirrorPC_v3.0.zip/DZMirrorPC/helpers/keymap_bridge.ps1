param(
  [Parameter(Mandatory = $true)][string]$WindowTitle,
  [Parameter(Mandatory = $true)][string]$ConfigPath
)

$ErrorActionPreference = 'SilentlyContinue'

$csharp = @"
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

public class DZKeymapEngineV3 {
    // =========================================================================
    // Win32 Structs & Constants (Multi-Touch InjectTouchInput + Hooks + ClipCursor)
    // =========================================================================
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }

    [StructLayout(LayoutKind.Sequential)]
    public struct POINT { public int X; public int Y; }

    [StructLayout(LayoutKind.Sequential)]
    public struct MSLLHOOKSTRUCT {
        public POINT pt;
        public uint mouseData;
        public uint flags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct KBDLLHOOKSTRUCT {
        public uint vkCode;
        public uint scanCode;
        public uint flags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    // Pointer / Touch Injection API (Windows 8/10/11 Native Multi-Touch)
    public const uint PT_TOUCH = 0x00000002;
    public const uint TOUCH_FEEDBACK_NONE = 0x00000003;
    public const uint TOUCH_MASK_CONTACTAREA = 0x00000001;
    public const uint TOUCH_MASK_ORIENTATION = 0x00000002;
    public const uint TOUCH_MASK_PRESSURE = 0x00000004;

    public const uint POINTER_FLAG_NONE = 0x00000000;
    public const uint POINTER_FLAG_INRANGE = 0x00000002;
    public const uint POINTER_FLAG_INCONTACT = 0x00000004;
    public const uint POINTER_FLAG_DOWN = 0x00010000;
    public const uint POINTER_FLAG_UPDATE = 0x00020000;
    public const uint POINTER_FLAG_UP = 0x00040000;

    [StructLayout(LayoutKind.Sequential)]
    public struct POINTER_INFO {
        public uint pointerType;
        public uint pointerId;
        public uint frameId;
        public uint pointerFlags;
        public IntPtr sourceDevice;
        public IntPtr hwndTarget;
        public POINT ptPixelLocation;
        public POINT ptHimetricLocation;
        public POINT ptPixelLocationRaw;
        public POINT ptHimetricLocationRaw;
        public uint dwTime;
        public uint historyCount;
        public int inputData;
        public uint dwKeyStates;
        public ulong PerformanceCount;
        public int ButtonChangeType;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct POINTER_TOUCH_INFO {
        public POINTER_INFO pointerInfo;
        public uint touchFlags;
        public uint touchMask;
        public RECT rcContact;
        public RECT rcContactRaw;
        public uint orientation;
        public uint pressure;
    }

    // Fallback SendInput structs (only if InjectTouchInput unavailable)
    [StructLayout(LayoutKind.Sequential)]
    public struct INPUT { public uint type; public MOUSEINPUT mi; }

    [StructLayout(LayoutKind.Sequential)]
    public struct MOUSEINPUT {
        public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo;
    }

    private const uint INPUT_MOUSE = 0;
    private const uint MOUSEEVENTF_MOVE = 0x0001;
    private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    private const uint MOUSEEVENTF_LEFTUP = 0x0004;
    private const uint MOUSEEVENTF_ABSOLUTE = 0x8000;

    private const int WH_KEYBOARD_LL = 13;
    private const int WH_MOUSE_LL = 14;

    private const int WM_KEYDOWN = 0x0100;
    private const int WM_KEYUP = 0x0101;
    private const int WM_SYSKEYDOWN = 0x0104;
    private const int WM_SYSKEYUP = 0x0105;

    private const int WM_MOUSEMOVE = 0x0200;
    private const int WM_LBUTTONDOWN = 0x0201;
    private const int WM_LBUTTONUP = 0x0202;
    private const int WM_RBUTTONDOWN = 0x0204;
    private const int WM_RBUTTONUP = 0x0205;
    private const int WM_MBUTTONDOWN = 0x0207;
    private const int WM_MBUTTONUP = 0x0208;
    private const int WM_MOUSEWHEEL = 0x020A;
    private const int WM_XBUTTONDOWN = 0x020B;
    private const int WM_XBUTTONUP = 0x020C;

    // Virtual codes for mouse buttons so unified keymap handles both Keyboard & Mouse
    private const int VK_LMB = 0x1001;
    private const int VK_RMB = 0x1002;
    private const int VK_MMB = 0x1003;
    private const int VK_X1  = 0x1004;
    private const int VK_X2  = 0x1005;
    private const int VK_WUP = 0x1006;
    private const int VK_WDN = 0x1007;

    private delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string lpModuleName);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern bool GetClientRect(IntPtr hWnd, out RECT lpRect);

    [DllImport("user32.dll")]
    private static extern bool ClientToScreen(IntPtr hWnd, ref POINT lpPoint);

    [DllImport("user32.dll")]
    private static extern bool IsWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsIconic(IntPtr hWnd);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool InitializeTouchInjection(uint maxCount, uint dwMode);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool InjectTouchInput(uint count, [MarshalAs(UnmanagedType.LPArray), In] POINTER_TOUCH_INFO[] contacts);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("user32.dll")]
    private static extern int GetSystemMetrics(int nIndex);

    [DllImport("user32.dll")]
    private static extern bool SetCursorPos(int X, int Y);

    [DllImport("user32.dll")]
    private static extern bool ClipCursor(ref RECT lpRect);

    [DllImport("user32.dll")]
    private static extern bool ClipCursor(IntPtr lpRect);

    [DllImport("winmm.dll")]
    private static extern uint timeBeginPeriod(uint uPeriod);

    [DllImport("winmm.dll")]
    private static extern uint timeEndPeriod(uint uPeriod);

    // =========================================================================
    // Touch Contact State (Up to 10 Simultaneous Multi-Touch Fingers)
    // =========================================================================
    private class TouchContact {
        public uint PointerId;
        public int X;
        public int Y;
        public bool Active;
        public bool NeedDown;
        public bool NeedUp;
        public bool PendingRecenterDown;
        public int RecenterX;
        public int RecenterY;
    }

    private class ButtonDef {
        public string Id;
        public string Type; // joystick, aim, freelook, click, hold, dblclick, toggle
        public string Action; // fire, ads, unlock_ui
        public int Vk;
        public int VkUp, VkDown, VkLeft, VkRight, VkSprint;
        public double X, Y, Radius, SprintRadius, Sensitivity;
        public bool AutoSprint;
    }

    private class ScheduledTap {
        public uint PointerId;
        public int X, Y;
        public long DownAtMs;
        public long UpAtMs;
        public bool DownSent;
        public bool Done;
        public string ButtonId;
    }

    // Engine state
    private static readonly object _sync = new object();
    private static volatile bool _running = true;
    private static bool _touchInjectionReady = false;

    private static IntPtr _kbHookId = IntPtr.Zero;
    private static IntPtr _msHookId = IntPtr.Zero;
    private static HookProc _kbProc;
    private static HookProc _msProc;

    private static string _targetTitle = "";
    private static string _configPath = "";
    private static DateTime _lastConfigWrite = DateTime.MinValue;
    private static IntPtr _targetHwnd = IntPtr.Zero;
    private static int _winX = 0, _winY = 0, _winW = 0, _winH = 0;
    private static bool _winVisible = false;
    private static bool _targetFocused = false;

    // Config
    private static bool _enabled = true;
    private static bool _editMode = false;
    private static List<ButtonDef> _buttons = new List<ButtonDef>();
    private static ButtonDef _joyBtn = null;
    private static ButtonDef _aimBtn = null;
    private static ButtonDef _freeLookBtn = null;

    // Mouse Lock & 360 Aim Settings
    private static bool _mouseEnabled = true;
    private static int _lockVk = 0xA2;       // LCTRL
    private static int _freeLookVk = 0xA4;   // LALT
    private static double _sensX = 1.0;
    private static double _sensY = 1.0;
    private static double _scopeSens = 0.65;
    private static double _dpiScale = 1.0;
    private static double _smoothing = 0.22;
    private static bool _invertY = false;
    private static bool _autoUnlockOnBag = true;
    private static bool _adsToggleMode = false;

    // Live runtime control state
    private static bool _mouseLocked = false;
    private static bool _freeLookActive = false;
    private static bool _adsActive = false;
    private static int _lockCenterX = 0, _lockCenterY = 0;
    private static bool _ignoreNextWarp = false;
    private static double _pendingDeltaX = 0, _pendingDeltaY = 0;
    private static double _smoothVx = 0, _smoothVy = 0;

    // Aim & FreeLook virtual finger positions (screen coordinates)
    private static double _aimFingerX = 0, _aimFingerY = 0;
    private static long _lastAimMoveMs = 0;
    private static double _eyeFingerX = 0, _eyeFingerY = 0;

    // Joystick smooth state
    private static double _joyCurX = 0, _joyCurY = 0;
    private static bool _joyActive = false;
    private static bool _joySprinting = false;
    private static long _joyForwardSinceMs = 0;

    // Pressed keys & toggles
    private static HashSet<int> _pressedVks = new HashSet<int>();
    private static Dictionary<string, bool> _toggleStates = new Dictionary<string, bool>();
    private static Dictionary<string, uint> _buttonPointerMap = new Dictionary<string, uint>();
    private static List<ScheduledTap> _scheduledTaps = new List<ScheduledTap>();

    // Touch pool: 1=Joystick, 2=Aim360, 3=FreeLook, 4..10=Buttons
    private static Dictionary<uint, TouchContact> _contacts = new Dictionary<uint, TouchContact>();
    private static uint _nextBtnSlot = 4;
    private static Stopwatch _sw = Stopwatch.StartNew();

    // =========================================================================
    // Entry Point
    // =========================================================================
    public static void Start(string title, string configPath) {
        _targetTitle = title;
        _configPath = configPath;

        for (uint i = 1; i <= 10; i++) {
            _contacts[i] = new TouchContact { PointerId = i };
        }

        try {
            _touchInjectionReady = InitializeTouchInjection(10, TOUCH_FEEDBACK_NONE);
        } catch {
            _touchInjectionReady = false;
        }
        Emit("TOUCH_MODE:" + (_touchInjectionReady ? "INJECT" : "FALLBACK"));

        LoadConfig(true);
        timeBeginPeriod(1);

        _kbProc = KbHookCallback;
        _msProc = MouseHookCallback;
        using (Process curProcess = Process.GetCurrentProcess())
        using (ProcessModule curModule = curProcess.MainModule) {
            IntPtr hMod = GetModuleHandle(curModule.ModuleName);
            _kbHookId = SetWindowsHookEx(WH_KEYBOARD_LL, _kbProc, hMod, 0);
            _msHookId = SetWindowsHookEx(WH_MOUSE_LL, _msProc, hMod, 0);
        }

        // Dedicated 120Hz Touch & Aim Engine Thread
        Thread engineThread = new Thread(EngineLoop);
        engineThread.IsBackground = true;
        engineThread.Priority = ThreadPriority.AboveNormal;
        engineThread.Start();

        // Stdin live command listener
        Thread stdinThread = new Thread(StdinLoop);
        stdinThread.IsBackground = true;
        stdinThread.Start();

        // Window tracker & config watcher on UI message pump (every 100ms)
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        timer.Interval = 100;
        timer.Tick += (s, e) => {
            LoadConfig(false);
            TrackWindow();
        };
        timer.Start();

        Application.Run();

        _running = false;
        ReleaseMouseLock();
        ReleaseAllTouches();
        if (_kbHookId != IntPtr.Zero) UnhookWindowsHookEx(_kbHookId);
        if (_msHookId != IntPtr.Zero) UnhookWindowsHookEx(_msHookId);
        timeEndPeriod(1);
    }

    private static void Emit(string msg) {
        try {
            Console.WriteLine(msg);
            Console.Out.Flush();
        } catch { }
    }

    private static void StdinLoop() {
        try {
            string line;
            while (_running && (line = Console.ReadLine()) != null) {
                line = line.Trim().ToUpperInvariant();
                if (line == "RELOAD") LoadConfig(true);
                else if (line == "UNLOCK") { lock (_sync) { ReleaseMouseLock(); } }
                else if (line == "LOCK") { lock (_sync) { if (_winVisible && _targetFocused) EngageMouseLock(); } }
                else if (line == "QUIT") { _running = false; Application.Exit(); break; }
            }
        } catch { }
    }

    // =========================================================================
    // Config Loader (Atomic retry-safe)
    // =========================================================================
    private static double GetDouble(Dictionary<string, object> d, string k, double defVal) {
        if (d != null && d.ContainsKey(k) && d[k] != null) {
            try { return Convert.ToDouble(d[k]); } catch { }
        }
        return defVal;
    }

    private static bool GetBool(Dictionary<string, object> d, string k, bool defVal) {
        if (d != null && d.ContainsKey(k) && d[k] != null) {
            try { return Convert.ToBoolean(d[k]); } catch { }
        }
        return defVal;
    }

    private static string GetStr(Dictionary<string, object> d, string k, string defVal) {
        if (d != null && d.ContainsKey(k) && d[k] != null) {
            return Convert.ToString(d[k]);
        }
        return defVal;
    }

    private static void LoadConfig(bool force) {
        try {
            if (!File.Exists(_configPath)) return;
            DateTime wt = File.GetLastWriteTimeUtc(_configPath);
            if (!force && wt == _lastConfigWrite) return;
            string json = null;
            for (int attempt = 0; attempt < 3; attempt++) {
                try {
                    json = File.ReadAllText(_configPath, Encoding.UTF8);
                    break;
                } catch { Thread.Sleep(15); }
            }
            if (string.IsNullOrEmpty(json)) return;
            _lastConfigWrite = wt;

            var ser = new JavaScriptSerializer();
            var obj = ser.Deserialize<Dictionary<string, object>>(json);
            if (obj == null) return;

            lock (_sync) {
                _enabled = GetBool(obj, "enabled", true);
                _editMode = GetBool(obj, "editMode", false);
                if (_editMode || !_enabled) {
                    ReleaseMouseLock();
                    ReleaseAllTouches();
                }

                if (obj.ContainsKey("mouse") && obj["mouse"] is Dictionary<string, object> m) {
                    _mouseEnabled = GetBool(m, "enabled", true);
                    _lockVk = KeyNameToVk(GetStr(m, "lockKey", "CTRL"));
                    if (_lockVk == 0) _lockVk = 0xA2;
                    _freeLookVk = KeyNameToVk(GetStr(m, "freeLookKey", "ALT"));
                    if (_freeLookVk == 0) _freeLookVk = 0xA4;
                    _sensX = Math.Max(0.1, Math.Min(5.0, GetDouble(m, "sensX", 1.0)));
                    _sensY = Math.Max(0.1, Math.Min(5.0, GetDouble(m, "sensY", 1.0)));
                    _scopeSens = Math.Max(0.1, Math.Min(3.0, GetDouble(m, "scopeSens", 0.65)));
                    _dpiScale = Math.Max(0.25, Math.Min(4.0, GetDouble(m, "dpiScale", 1.0)));
                    _smoothing = Math.Max(0.0, Math.Min(0.85, GetDouble(m, "smoothing", 0.22)));
                    _invertY = GetBool(m, "invertY", false);
                    _autoUnlockOnBag = GetBool(m, "autoUnlockOnBag", true);
                    _adsToggleMode = GetStr(m, "adsMode", "hold").ToLowerInvariant() == "toggle";
                }

                var list = new List<ButtonDef>();
                ButtonDef joy = null, aim = null, eye = null;

                if (obj.ContainsKey("buttons") && obj["buttons"] is System.Collections.ArrayList arr) {
                    foreach (var item in arr) {
                        if (!(item is Dictionary<string, object> d)) continue;
                        string type = GetStr(d, "type", "click").ToLowerInvariant();
                        if (type == "tap") type = "click";
                        var bd = new ButtonDef {
                            Id = GetStr(d, "id", ""),
                            Type = type,
                            Action = GetStr(d, "action", "").ToLowerInvariant(),
                            X = GetDouble(d, "x", 50),
                            Y = GetDouble(d, "y", 50),
                            Radius = GetDouble(d, "radius", 11),
                            SprintRadius = GetDouble(d, "sprintRadius", 19),
                            Sensitivity = GetDouble(d, "sensitivity", 1.0),
                            AutoSprint = GetBool(d, "autoSprint", true),
                            Vk = KeyNameToVk(GetStr(d, "key", "")),
                            VkUp = KeyNameToVk(GetStr(d, "up", "W")),
                            VkDown = KeyNameToVk(GetStr(d, "down", "S")),
                            VkLeft = KeyNameToVk(GetStr(d, "left", "A")),
                            VkRight = KeyNameToVk(GetStr(d, "right", "D")),
                            VkSprint = KeyNameToVk(GetStr(d, "sprint", "SHIFT"))
                        };
                        list.Add(bd);
                        if (type == "joystick" && joy == null) joy = bd;
                        else if (type == "aim" && aim == null) aim = bd;
                        else if (type == "freelook" && eye == null) eye = bd;
                    }
                }
                _buttons = list;
                _joyBtn = joy;
                _aimBtn = aim;
                _freeLookBtn = eye;
            }
        } catch { }
    }

    // =========================================================================
    // Window Tracking & Focus Guard (Zero Stuck Keys)
    // =========================================================================
    private static void TrackWindow() {
        if (_targetHwnd == IntPtr.Zero || !IsWindow(_targetHwnd)) {
            _targetHwnd = FindWindow(null, _targetTitle);
        }
        bool vis = false;
        int nx = 0, ny = 0, nw = 0, nh = 0;

        if (_targetHwnd != IntPtr.Zero && IsWindow(_targetHwnd) && !IsIconic(_targetHwnd)) {
            RECT rc;
            if (GetClientRect(_targetHwnd, out rc)) {
                POINT pt = new POINT { X = 0, Y = 0 };
                ClientToScreen(_targetHwnd, ref pt);
                nw = rc.Right - rc.Left;
                nh = rc.Bottom - rc.Top;
                if (nw > 20 && nh > 20) {
                    nx = pt.X; ny = pt.Y; vis = true;
                }
            }
        }

        bool focused = vis && (GetForegroundWindow() == _targetHwnd);

        lock (_sync) {
            bool boundsChanged = (vis != _winVisible || nx != _winX || ny != _winY || nw != _winW || nh != _winH);
            _winVisible = vis;
            _winX = nx; _winY = ny; _winW = nw; _winH = nh;
            _lockCenterX = _winX + _winW / 2;
            _lockCenterY = _winY + _winH / 2;

            if (_targetFocused && !focused) {
                // Focus lost -> immediately release mouse lock and all active touches!
                ReleaseMouseLock();
                ReleaseAllTouches();
            }
            _targetFocused = focused;

            if (_mouseLocked && boundsChanged && vis) {
                ApplyClipRect();
            }

            if (boundsChanged) {
                if (vis) Emit("BOUNDS:1," + nx + "," + ny + "," + nw + "," + nh);
                else Emit("BOUNDS:0,0,0,0,0");
            }
        }
    }

    private static void ApplyClipRect() {
        RECT r = new RECT {
            Left = _winX + 4,
            Top = _winY + 4,
            Right = _winX + _winW - 4,
            Bottom = _winY + _winH - 4
        };
        ClipCursor(ref r);
    }

    private static void EngageMouseLock() {
        if (!_mouseEnabled || !_winVisible || _editMode) return;
        _mouseLocked = true;
        _pendingDeltaX = 0; _pendingDeltaY = 0;
        _smoothVx = 0; _smoothVy = 0;
        _lockCenterX = _winX + _winW / 2;
        _lockCenterY = _winY + _winH / 2;
        ApplyClipRect();
        _ignoreNextWarp = true;
        SetCursorPos(_lockCenterX, _lockCenterY);
        Emit("MOUSELOCK:1");
    }

    private static void ReleaseMouseLock() {
        if (!_mouseLocked && !_freeLookActive) return;
        _mouseLocked = false;
        _freeLookActive = false;
        _adsActive = false;
        _pendingDeltaX = 0; _pendingDeltaY = 0;
        _smoothVx = 0; _smoothVy = 0;
        ClipCursor(IntPtr.Zero);
        ReleaseContact(2);
        ReleaseContact(3);
        Emit("MOUSELOCK:0");
        Emit("FREELOOK:0");
    }

    private static void ReleaseAllTouches() {
        _pressedVks.Clear();
        _toggleStates.Clear();
        _scheduledTaps.Clear();
        _joyActive = false;
        _joySprinting = false;
        _adsActive = false;
        _freeLookActive = false;
        foreach (var kv in _contacts) {
            if (kv.Value.Active) kv.Value.NeedUp = true;
            kv.Value.NeedDown = false;
            kv.Value.PendingRecenterDown = false;
        }
    }

    private static void ReleaseContact(uint pid) {
        if (_contacts.ContainsKey(pid)) {
            var c = _contacts[pid];
            if (c.Active) c.NeedUp = true;
            c.NeedDown = false;
            c.PendingRecenterDown = false;
        }
    }

    private static uint GetSlotForButton(string id) {
        if (_buttonPointerMap.ContainsKey(id)) return _buttonPointerMap[id];
        uint slot = _nextBtnSlot++;
        if (_nextBtnSlot > 10) _nextBtnSlot = 4;
        _buttonPointerMap[id] = slot;
        return slot;
    }

    private static int PctX(double pct) { return (int)Math.Round(_winX + (pct / 100.0) * _winW); }
    private static int PctY(double pct) { return (int)Math.Round(_winY + (pct / 100.0) * _winH); }

    // =========================================================================
    // 120Hz High-Precision Engine Loop (Joystick + 360° Aim + FreeLook + Multi-Touch)
    // =========================================================================
    private static void EngineLoop() {
        while (_running) {
            long now = _sw.ElapsedMilliseconds;
            List<POINTER_TOUCH_INFO> frame = null;

            lock (_sync) {
                if (_winVisible && _enabled && !_editMode) {
                    UpdateJoystickTick(now);
                    UpdateAimAndFreeLookTick(now);
                    UpdateScheduledTapsTick(now);
                }
                frame = BuildTouchFrame();
            }

            if (frame != null && frame.Count > 0) {
                if (_touchInjectionReady) {
                    InjectTouchInput((uint)frame.Count, frame.ToArray());
                } else {
                    // Fallback single-pointer SendInput for legacy Windows 7
                    var primary = frame[0];
                    uint fl = 0;
                    if ((primary.pointerInfo.pointerFlags & POINTER_FLAG_DOWN) != 0) fl = MOUSEEVENTF_LEFTDOWN;
                    else if ((primary.pointerInfo.pointerFlags & POINTER_FLAG_UP) != 0) fl = MOUSEEVENTF_LEFTUP;
                    SendFallbackMouse(primary.pointerInfo.ptPixelLocation.X, primary.pointerInfo.ptPixelLocation.Y, fl);
                }
            }

            Thread.Sleep(8); // ~120Hz tick rate
        }
    }

    private static void UpdateJoystickTick(long now) {
        if (_joyBtn == null) return;
        int dx = 0, dy = 0;
        if (_pressedVks.Contains(_joyBtn.VkLeft)) dx -= 1;
        if (_pressedVks.Contains(_joyBtn.VkRight)) dx += 1;
        if (_pressedVks.Contains(_joyBtn.VkUp)) dy -= 1;
        if (_pressedVks.Contains(_joyBtn.VkDown)) dy += 1;

        double cx = PctX(_joyBtn.X);
        double cy = PctY(_joyBtn.Y);
        double minDim = Math.Min(_winW, _winH);
        double baseRad = (_joyBtn.Radius / 100.0) * minDim * Math.Max(0.4, _joyBtn.Sensitivity);
        double sprintRad = (_joyBtn.SprintRadius / 100.0) * minDim;

        var c = _contacts[1];

        if (dx == 0 && dy == 0) {
            _joyForwardSinceMs = 0;
            if (_joyActive) {
                _joyActive = false;
                _joySprinting = false;
                c.X = (int)Math.Round(cx);
                c.Y = (int)Math.Round(cy);
                c.NeedUp = true;
                Emit("KEY:JOY:0");
                Emit("JOY:0,0,0");
            }
            return;
        }

        if (dy < 0 && dx == 0) {
            if (_joyForwardSinceMs == 0) _joyForwardSinceMs = now;
        } else {
            _joyForwardSinceMs = 0;
        }

        bool shiftHeld = _pressedVks.Contains(_joyBtn.VkSprint) || _pressedVks.Contains(0xA0) || _pressedVks.Contains(0xA1);
        bool autoSprintTriggered = _joyBtn.AutoSprint && dy < 0 && dx == 0 && _joyForwardSinceMs > 0 && (now - _joyForwardSinceMs >= 350);
        bool sprinting = (dy < 0) && (shiftHeld || autoSprintTriggered);

        double len = Math.Sqrt(dx * dx + dy * dy);
        double nx = dx / len;
        double ny = dy / len;
        double rad = sprinting ? sprintRad : Math.Min(sprintRad, baseRad);
        double targetX = cx + nx * rad;
        double targetY = cy + ny * rad;

        if (!_joyActive) {
            _joyActive = true;
            _joySprinting = sprinting;
            _joyCurX = cx;
            _joyCurY = cy;
            c.X = (int)Math.Round(cx);
            c.Y = (int)Math.Round(cy);
            c.NeedDown = true;
            Emit("KEY:JOY:1");
        } else {
            // Smooth exponential glide between walk, run, and sprint
            double lerp = 0.42;
            _joyCurX += (targetX - _joyCurX) * lerp;
            _joyCurY += (targetY - _joyCurY) * lerp;
            c.X = (int)Math.Round(_joyCurX);
            c.Y = (int)Math.Round(_joyCurY);
            if (sprinting != _joySprinting) {
                _joySprinting = sprinting;
                Emit("JOY:" + nx.ToString("F2") + "," + ny.ToString("F2") + "," + (sprinting ? "1" : "0"));
            }
        }
    }

    private static void UpdateAimAndFreeLookTick(long now) {
        if (!_mouseLocked) return;

        double rawDx = _pendingDeltaX;
        double rawDy = _pendingDeltaY;
        _pendingDeltaX = 0;
        _pendingDeltaY = 0;

        double scopeMul = _adsActive ? _scopeSens : 1.0;
        double scaledX = rawDx * _sensX * _dpiScale * scopeMul;
        double scaledY = rawDy * _sensY * _dpiScale * scopeMul * (_invertY ? -1.0 : 1.0);

        double alpha = 1.0 - _smoothing;
        _smoothVx = _smoothVx * (1.0 - alpha) + scaledX * alpha;
        _smoothVy = _smoothVy * (1.0 - alpha) + scaledY * alpha;

        if (Math.Abs(_smoothVx) < 0.05) _smoothVx = 0;
        if (Math.Abs(_smoothVy) < 0.05) _smoothVy = 0;

        // Free Look Mode (Alt held -> Contact 3 on PUBG Eye button)
        if (_freeLookActive && _freeLookBtn != null) {
            ReleaseContact(2);
            var eyeC = _contacts[3];
            int eyeOriginX = PctX(_freeLookBtn.X);
            int eyeOriginY = PctY(_freeLookBtn.Y);

            if (!eyeC.Active && !eyeC.NeedDown) {
                _eyeFingerX = eyeOriginX;
                _eyeFingerY = eyeOriginY;
                eyeC.X = eyeOriginX;
                eyeC.Y = eyeOriginY;
                eyeC.NeedDown = true;
            } else if (_smoothVx != 0 || _smoothVy != 0) {
                _eyeFingerX = Math.Max(_winX + 20, Math.Min(_winX + _winW - 20, _eyeFingerX + _smoothVx));
                _eyeFingerY = Math.Max(_winY + 20, Math.Min(_winY + _winH - 20, _eyeFingerY + _smoothVy));
                eyeC.X = (int)Math.Round(_eyeFingerX);
                eyeC.Y = (int)Math.Round(_eyeFingerY);
            }
            return;
        }

        // Standard 360° Infinite Camera Aim (Contact 2 in right-hand Aim Zone)
        var aimC = _contacts[2];
        double aimPctX = _aimBtn != null ? _aimBtn.X : 66.0;
        double aimPctY = _aimBtn != null ? _aimBtn.Y : 46.0;
        double aimRadPct = _aimBtn != null ? _aimBtn.Radius : 22.0;

        int originX = PctX(aimPctX);
        int originY = PctY(aimPctY);
        int halfBoxX = Math.Max(60, (int)Math.Round((aimRadPct / 100.0) * _winW));
        int halfBoxY = Math.Max(50, (int)Math.Round((aimRadPct / 100.0) * _winH));

        int minX = Math.Max(_winX + 24, originX - halfBoxX);
        int maxX = Math.Min(_winX + _winW - 24, originX + halfBoxX);
        int minY = Math.Max(_winY + 24, originY - halfBoxY);
        int maxY = Math.Min(_winY + _winH - 24, originY + halfBoxY);

        if (aimC.PendingRecenterDown) {
            aimC.PendingRecenterDown = false;
            _aimFingerX = aimC.RecenterX + _smoothVx;
            _aimFingerY = aimC.RecenterY + _smoothVy;
            aimC.X = (int)Math.Round(_aimFingerX);
            aimC.Y = (int)Math.Round(_aimFingerY);
            aimC.NeedDown = true;
            _lastAimMoveMs = now;
            return;
        }

        if (_smoothVx != 0 || _smoothVy != 0) {
            _lastAimMoveMs = now;
            if (!aimC.Active && !aimC.NeedDown) {
                _aimFingerX = originX;
                _aimFingerY = originY;
                aimC.X = originX;
                aimC.Y = originY;
                aimC.NeedDown = true;
            } else {
                double nextX = _aimFingerX + _smoothVx;
                double nextY = _aimFingerY + _smoothVy;

                // Seamless 360° edge recenter: lift finger on this tick, touch down at origin on next tick!
                if (nextX <= minX || nextX >= maxX || nextY <= minY || nextY >= maxY) {
                    aimC.NeedUp = true;
                    aimC.PendingRecenterDown = true;
                    aimC.RecenterX = originX;
                    aimC.RecenterY = originY;
                } else {
                    _aimFingerX = nextX;
                    _aimFingerY = nextY;
                    aimC.X = (int)Math.Round(_aimFingerX);
                    aimC.Y = (int)Math.Round(_aimFingerY);
                }
            }
        } else if (aimC.Active && (now - _lastAimMoveMs > 320)) {
            // Release idle aim finger cleanly so it doesn't block UI taps
            aimC.NeedUp = true;
        }
    }

    private static void UpdateScheduledTapsTick(long now) {
        for (int i = _scheduledTaps.Count - 1; i >= 0; i--) {
            var t = _scheduledTaps[i];
            var c = _contacts[t.PointerId];
            if (!t.DownSent && now >= t.DownAtMs) {
                t.DownSent = true;
                c.X = t.X; c.Y = t.Y;
                c.NeedDown = true;
                Emit("KEY:" + t.ButtonId + ":1");
            }
            if (t.DownSent && !t.Done && now >= t.UpAtMs) {
                t.Done = true;
                c.X = t.X; c.Y = t.Y;
                c.NeedUp = true;
                Emit("KEY:" + t.ButtonId + ":0");
                _scheduledTaps.RemoveAt(i);
            }
        }
    }

    private static List<POINTER_TOUCH_INFO> BuildTouchFrame() {
        var frame = new List<POINTER_TOUCH_INFO>();
        foreach (var kv in _contacts) {
            var c = kv.Value;
            uint flags = 0;

            if (c.NeedUp) {
                flags = POINTER_FLAG_UP;
                c.NeedUp = false;
                c.Active = false;
            } else if (c.NeedDown) {
                flags = POINTER_FLAG_DOWN | POINTER_FLAG_INRANGE | POINTER_FLAG_INCONTACT;
                c.NeedDown = false;
                c.Active = true;
            } else if (c.Active) {
                flags = POINTER_FLAG_UPDATE | POINTER_FLAG_INRANGE | POINTER_FLAG_INCONTACT;
            } else {
                continue;
            }

            var ti = new POINTER_TOUCH_INFO();
            ti.pointerInfo.pointerType = PT_TOUCH;
            ti.pointerInfo.pointerId = c.PointerId;
            ti.pointerInfo.pointerFlags = flags;
            ti.pointerInfo.ptPixelLocation = new POINT { X = c.X, Y = c.Y };
            ti.touchFlags = 0;
            ti.touchMask = TOUCH_MASK_CONTACTAREA | TOUCH_MASK_ORIENTATION | TOUCH_MASK_PRESSURE;
            ti.orientation = 90;
            ti.pressure = (flags == POINTER_FLAG_UP) ? 0u : 512u;
            ti.rcContact = new RECT { Left = c.X - 4, Top = c.Y - 4, Right = c.X + 4, Bottom = c.Y + 4 };
            frame.Add(ti);
        }
        return frame;
    }

    private static void SendFallbackMouse(int screenX, int screenY, uint flags) {
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        if (sw <= 0 || sh <= 0) return;
        int absX = (int)Math.Round((double)screenX * 65535.0 / (sw - 1));
        int absY = (int)Math.Round((double)screenY * 65535.0 / (sh - 1));
        INPUT[] inp = new INPUT[1];
        inp[0].type = INPUT_MOUSE;
        inp[0].mi.dx = absX;
        inp[0].mi.dy = absY;
        inp[0].mi.dwFlags = MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE | flags;
        SendInput(1, inp, Marshal.SizeOf(typeof(INPUT)));
    }

    // =========================================================================
    // Low-Level Keyboard Hook (Non-Blocking, Zero Thread.Sleep!)
    // =========================================================================
    private static IntPtr KbHookCallback(int nCode, IntPtr wParam, IntPtr lParam) {
        if (nCode >= 0) {
            int msg = wParam.ToInt32();
            var kb = (KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(KBDLLHOOKSTRUCT));
            int vk = (int)kb.vkCode;
            bool isDown = (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN);
            bool isUp = (msg == WM_KEYUP || msg == WM_SYSKEYUP);

            if (isDown && vk == 0x78) { // F9 toggles overlay visibility
                Emit("TOGGLE_VIS");
            }

            bool swallow = false;
            lock (_sync) {
                if (_enabled && !_editMode && _winVisible && _targetFocused) {
                    // ESC always unlocks mouse cursor safely
                    if (isDown && vk == 0x1B && _mouseLocked) {
                        ReleaseMouseLock();
                    }

                    // Toggle Mouse Lock key (e.g. CTRL or ~)
                    if (vk == _lockVk || (_lockVk == 0xA2 && vk == 0xA3)) {
                        if (isDown && !_pressedVks.Contains(vk)) {
                            _pressedVks.Add(vk);
                            if (_mouseLocked) ReleaseMouseLock();
                            else EngageMouseLock();
                            swallow = true;
                        } else if (isUp) {
                            _pressedVks.Remove(vk);
                            swallow = true;
                        } else if (isDown) {
                            swallow = true;
                        }
                    }
                    // Free Look key (e.g. ALT)
                    else if (_mouseLocked && (vk == _freeLookVk || (_freeLookVk == 0xA4 && vk == 0xA5))) {
                        if (isDown && !_freeLookActive) {
                            _freeLookActive = true;
                            Emit("FREELOOK:1");
                            swallow = true;
                        } else if (isUp && _freeLookActive) {
                            _freeLookActive = false;
                            ReleaseContact(3);
                            Emit("FREELOOK:0");
                            swallow = true;
                        } else if (isDown) {
                            swallow = true;
                        }
                    }
                    // Joystick keys (WASD + Shift)
                    else if (_joyBtn != null && (vk == _joyBtn.VkUp || vk == _joyBtn.VkDown || vk == _joyBtn.VkLeft || vk == _joyBtn.VkRight || vk == _joyBtn.VkSprint)) {
                        if (isDown) _pressedVks.Add(vk);
                        if (isUp) _pressedVks.Remove(vk);
                        swallow = true;
                    }
                    // Mapped Buttons (Click / Hold / Double-Click / Toggle)
                    else {
                        swallow = HandleMappedInput(vk, isDown, isUp);
                    }
                }
            }
            if (swallow) return (IntPtr)1;
        }
        return CallNextHookEx(_kbHookId, nCode, wParam, lParam);
    }

    // =========================================================================
    // Low-Level Mouse Hook (Relative 360° Capture + LMB Fire + RMB ADS)
    // =========================================================================
    private static IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam) {
        if (nCode >= 0) {
            int msg = wParam.ToInt32();
            var ms = (MSLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(MSLLHOOKSTRUCT));

            bool swallow = false;
            lock (_sync) {
                if (_enabled && !_editMode && _winVisible && _targetFocused && _mouseLocked) {
                    if (msg == WM_MOUSEMOVE) {
                        if (_ignoreNextWarp) {
                            _ignoreNextWarp = false;
                        } else {
                            int dx = ms.pt.X - _lockCenterX;
                            int dy = ms.pt.Y - _lockCenterY;
                            if (dx != 0 || dy != 0) {
                                _pendingDeltaX += dx;
                                _pendingDeltaY += dy;
                                _ignoreNextWarp = true;
                                SetCursorPos(_lockCenterX, _lockCenterY);
                            }
                        }
                        swallow = true;
                    } else if (msg == WM_LBUTTONDOWN) {
                        swallow = HandleMappedInput(VK_LMB, true, false);
                    } else if (msg == WM_LBUTTONUP) {
                        swallow = HandleMappedInput(VK_LMB, false, true);
                    } else if (msg == WM_RBUTTONDOWN) {
                        swallow = HandleMappedInput(VK_RMB, true, false);
                    } else if (msg == WM_RBUTTONUP) {
                        swallow = HandleMappedInput(VK_RMB, false, true);
                    } else if (msg == WM_MBUTTONDOWN) {
                        swallow = HandleMappedInput(VK_MMB, true, false);
                    } else if (msg == WM_MBUTTONUP) {
                        swallow = HandleMappedInput(VK_MMB, false, true);
                    } else if (msg == WM_XBUTTONDOWN) {
                        int xbtn = (int)((ms.mouseData >> 16) & 0xFFFF);
                        swallow = HandleMappedInput(xbtn == 1 ? VK_X1 : VK_X2, true, false);
                    } else if (msg == WM_XBUTTONUP) {
                        int xbtn = (int)((ms.mouseData >> 16) & 0xFFFF);
                        swallow = HandleMappedInput(xbtn == 1 ? VK_X1 : VK_X2, false, true);
                    } else if (msg == WM_MOUSEWHEEL) {
                        short delta = (short)((ms.mouseData >> 16) & 0xFFFF);
                        swallow = HandleMappedInput(delta > 0 ? VK_WUP : VK_WDN, true, false);
                    }
                }
            }
            if (swallow) return (IntPtr)1;
        }
        return CallNextHookEx(_msHookId, nCode, wParam, lParam);
    }

    private static bool HandleMappedInput(int vk, bool isDown, bool isUp) {
        long now = _sw.ElapsedMilliseconds;
        foreach (var b in _buttons) {
            if (b.Type == "joystick" || b.Type == "aim" || b.Type == "freelook") continue;
            if (b.Vk == 0 || b.Vk != vk) continue;

            int px = PctX(b.X);
            int py = PctY(b.Y);
            uint slot = GetSlotForButton(b.Id);
            var c = _contacts[slot];

            // Auto-unlock cursor on Bag/Map UI keys if configured
            if (isDown && _autoUnlockOnBag && b.Action == "unlock_ui" && _mouseLocked) {
                ReleaseMouseLock();
            }

            if (b.Type == "toggle" || (b.Action == "ads" && _adsToggleMode)) {
                if (isDown && !_pressedVks.Contains(vk)) {
                    _pressedVks.Add(vk);
                    bool cur = _toggleStates.ContainsKey(b.Id) && _toggleStates[b.Id];
                    bool next = !cur;
                    _toggleStates[b.Id] = next;
                    if (b.Action == "ads") _adsActive = next;
                    c.X = px; c.Y = py;
                    if (next) c.NeedDown = true;
                    else c.NeedUp = true;
                    Emit("KEY:" + b.Id + ":" + (next ? "1" : "0"));
                } else if (isUp) {
                    _pressedVks.Remove(vk);
                }
                return true;
            }
            else if (b.Type == "dblclick") {
                if (isDown && !_pressedVks.Contains(vk)) {
                    _pressedVks.Add(vk);
                    _scheduledTaps.Add(new ScheduledTap { PointerId = slot, X = px, Y = py, DownAtMs = now, UpAtMs = now + 35, ButtonId = b.Id });
                    _scheduledTaps.Add(new ScheduledTap { PointerId = slot, X = px, Y = py, DownAtMs = now + 80, UpAtMs = now + 115, ButtonId = b.Id });
                } else if (isUp) {
                    _pressedVks.Remove(vk);
                }
                return true;
            }
            else if (b.Type == "click") {
                if (isDown && !_pressedVks.Contains(vk)) {
                    _pressedVks.Add(vk);
                    _scheduledTaps.Add(new ScheduledTap { PointerId = slot, X = px, Y = py, DownAtMs = now, UpAtMs = now + 42, ButtonId = b.Id });
                } else if (isUp) {
                    _pressedVks.Remove(vk);
                }
                return true;
            }
            else { // hold
                if (isDown && !_pressedVks.Contains(vk)) {
                    _pressedVks.Add(vk);
                    if (b.Action == "ads") _adsActive = true;
                    c.X = px; c.Y = py;
                    c.NeedDown = true;
                    Emit("KEY:" + b.Id + ":1");
                } else if (isUp && _pressedVks.Contains(vk)) {
                    _pressedVks.Remove(vk);
                    if (b.Action == "ads") _adsActive = false;
                    c.X = px; c.Y = py;
                    c.NeedUp = true;
                    Emit("KEY:" + b.Id + ":0");
                }
                return true;
            }
        }
        return false;
    }

    // =========================================================================
    // Key Name -> Virtual Key Code Mapping (Keyboard + Mouse)
    // =========================================================================
    private static int KeyNameToVk(string key) {
        if (string.IsNullOrEmpty(key)) return 0;
        key = key.Trim().ToUpperInvariant();
        if (key.Length == 1) {
            char c = key[0];
            if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) return (int)c;
            if (c == '~' || c == '`') return 0xC0;
        }
        switch (key) {
            case "LMB": case "LEFTCLICK": return VK_LMB;
            case "RMB": case "RIGHTCLICK": return VK_RMB;
            case "MMB": case "MIDDLECLICK": return VK_MMB;
            case "X1": case "XBUTTON1": return VK_X1;
            case "X2": case "XBUTTON2": return VK_X2;
            case "WHEELUP": return VK_WUP;
            case "WHEELDOWN": return VK_WDN;
            case "SPACE": return 0x20;
            case "ENTER": return 0x0D;
            case "TAB": return 0x09;
            case "ESC": case "ESCAPE": return 0x1B;
            case "CAPSLOCK": return 0x14;
            case "SHIFT": case "LSHIFT": return 0xA0;
            case "RSHIFT": return 0xA1;
            case "CTRL": case "CONTROL": case "LCTRL": return 0xA2;
            case "RCTRL": return 0xA3;
            case "ALT": case "LALT": return 0xA4;
            case "RALT": return 0xA5;
            case "BACKSPACE": return 0x08;
            case "UP": case "ARROWUP": return 0x26;
            case "DOWN": case "ARROWDOWN": return 0x28;
            case "LEFT": case "ARROWLEFT": return 0x25;
            case "RIGHT": case "ARROWRIGHT": return 0x27;
            case "F1": return 0x70; case "F2": return 0x71; case "F3": return 0x72; case "F4": return 0x73;
            case "F5": return 0x74; case "F6": return 0x75; case "F7": return 0x76; case "F8": return 0x77;
            case "F9": return 0x78; case "F10": return 0x79; case "F11": return 0x7A; case "F12": return 0x7B;
            default: return 0;
        }
    }
}
"@

Add-Type -TypeDefinition $csharp -ReferencedAssemblies System.Windows.Forms, System.Web.Extensions
[DZKeymapEngineV3]::Start($WindowTitle, $ConfigPath)
